Engine API Surface (Tauri Commands)
==================================

This desktop rebuild intentionally does NOT expose hundreds of legacy UI helper functions from the original HTML.
Instead, we define a stable, small "engine API" that covers all features, and the new UI calls only these commands.

Commands (implemented as Tauri `#[command]` in Rust)
----------------------------------------------------

Weapon / Item
- engine_version() -> String
- parse_weapon_code(code: String) -> Weapon
- serialize_weapon(weapon: Weapon) -> String
- parse_bulk_input(text: String) -> Vec<String>   (extract @Ug... serials from pasted text)
- bulk_deserialize_serials(serials: Vec<String>) -> Vec<Weapon>      (stub)
- bulk_serialize_weapons(weapons: Vec<Weapon>) -> Vec<String>        (stub)

Brick Roll
- brick_roll(config: BrickRollConfig) -> Weapon                      (stub)

Save Editor (YAML/text operations)
- save_extract_serials_with_location(yaml_text: String) -> Vec<SerialWithLocation>   (stub)
- save_update_equipped_slot(req: UpdateEquippedSlotRequest) -> String                 (stub)
- save_add_item_to_backpack(req: AddItemRequest) -> String                            (stub)
- save_add_item_to_lost_loot(req: AddItemRequest) -> String                           (stub)
- save_remove_item(req: RemoveItemRequest) -> String                                  (stub)
- save_apply_preset(req: ApplyPresetRequest) -> String                                (stub)

Notes
-----
- The original HTML contains ~286 JS functions. A complete inventory is exported to:
  docs/legacy_functions.json
- As we port features, we implement the corresponding command and add golden tests.
