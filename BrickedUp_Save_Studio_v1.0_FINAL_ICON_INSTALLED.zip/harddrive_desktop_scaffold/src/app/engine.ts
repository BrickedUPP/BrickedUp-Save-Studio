import { invoke } from "@tauri-apps/api/core";

export type ParseWeaponCodeResponse = {
  normalized: string | null;
  serialized: string | null;
  breakdown: string | null;
};

export type ParseBulkInputResponse = {
  serials: string[];
  base85: string[];
  decoded: string[];
};

export type BrickRollRequest = {
  seed: number;
  intensity: number;
  baseCode: string | null;
};

export type BrickRollResponse = {
  deserialized: string | null;
  serialized: string | null;
  breakdown: string | null;
};

export type DeserializeResponse = {
  serial: string | null;
  error: string | null;
};

export type SerializeResponse = {
  serial_b85: string | null;
  error: string | null;
};

export type BulkConvertResponse = {
  output_lines: string[];
  ok: number;
  failed: number;
};

export const engine = {
  parseWeaponCode: (code: string) =>
    invoke<ParseWeaponCodeResponse>("parse_weapon_code", { code }),

  parseBulkInput: (text: string) =>
    invoke<ParseBulkInputResponse>("parse_bulk_input", { text }),

  ensureTrailingPipe: (s: string) =>
    invoke<string>("ensure_trailing_pipe", { s }),

  normalizeBulkInput: (text: string) =>
    invoke<string[]>("normalize_bulk_input", { text }),

  deserializeBase85: (serial_b85: string) =>
    invoke<DeserializeResponse>("deserialize_base85", { req: { serial_b85 } }),

  serializeDecoded: (decoded: string) =>
    invoke<SerializeResponse>("serialize_decoded", { req: { decoded } }),

  bulkDeserialize: (text: string) =>
    invoke<BulkConvertResponse>("bulk_deserialize", { text }),

  bulkSerialize: (text: string) =>
    invoke<BulkConvertResponse>("bulk_serialize", { text }),

  brickRoll: (req: BrickRollRequest) =>
    invoke<BrickRollResponse>("brick_roll", { req: { seed: req.seed, intensity: req.intensity, base_code: req.baseCode } }),
};

export type SerialWithLocation = {
  serial: string;
  index: number;
  location: string;
  slot: number | null;
  state_flags: number | null;
  in_machine: boolean | null;
};

export type SaveExtractResponse = {
  serials: SerialWithLocation[];
  unique_count: number;
};

export type BackpackSlot = {
  slot: number;
  serial: string;
  flags?: number | null;
  state_flags?: number | null;
};

export const saveEngine = {
  extractSerialsWithLocation: (yaml_text: string) =>
    invoke<SaveExtractResponse>("save_extract_serials_with_location", { yamlText: yaml_text } as any),

  setBackpackSlots: (yaml_text: string, slots: BackpackSlot[]) =>
    invoke<{ yaml_text: string }>("save_set_backpack_slots", { req: { yaml_text, slots } }),
};


export type EquippedSlot = {
  slot: number;
  serial: string;
  state_flags?: number | null;
};

export type LostLootEntry = {
  serial: string;
  in_machine?: boolean | null;
};

export const saveEngine2 = {
  setEquippedSlots: (yaml_text: string, slots: EquippedSlot[]) =>
    invoke<{ yaml_text: string }>("save_set_equipped_slots", { req: { yaml_text, slots } }),

  setLostLoot: (yaml_text: string, entries: LostLootEntry[]) =>
    invoke<{ yaml_text: string }>("save_set_lost_loot", { req: { yaml_text, entries } }),
};


export const saveEngine3 = {
  setBankSlots: (yaml_text: string, slots: BackpackSlot[]) =>
    invoke<{ yaml_text: string }>("save_set_bank_slots", { req: { yaml_text, slots } }),

  setVaultSlots: (yaml_text: string, slots: BackpackSlot[]) =>
    invoke<{ yaml_text: string }>("save_set_vault_slots", { req: { yaml_text, slots } }),
};


export type ReadTextFileResponse = { path: string; content: string };

export const fileEngine = {
  readTextFile: (path: string) => invoke<ReadTextFileResponse>("read_text_file", { path }),
  writeTextFile: (path: string, content: string) => invoke<void>("write_text_file", { req: { path, content } }),
};


export type SaveDecryptResponse = { path: string; file_name: string; yaml_text: string };
export type SaveEncryptResponse = { sav_bytes: number[] };

export const savEngine = {
  decryptSavFile: (path: string, steamid: string) =>
    invoke<SaveDecryptResponse>("save_decrypt_sav_file", { req: { path, steamid } }),

  decryptSavFileOffline: (path: string, steamid: string) =>
    invoke<SaveDecryptResponse>("save_decrypt_sav_file_offline", { req: { path, steamid } }),

  decryptSavFileAuto: (path: string, steamid: string, prefer_offline?: boolean, allow_remote_fallback?: boolean) =>
    invoke<SaveDecryptResponse>("save_decrypt_sav_file_auto", { req: { path, steamid, prefer_offline, allow_remote_fallback } }),

  encryptYaml: (steamid: string, yaml_text: string) =>
    invoke<SaveEncryptResponse>("save_encrypt_yaml", { req: { steamid, yaml_text } }),

  encryptYamlOffline: (steamid: string, yaml_text: string) =>
    invoke<SaveEncryptResponse>("save_encrypt_yaml_offline", { req: { steamid, yaml_text } }),

  encryptYamlAuto: (steamid: string, yaml_text: string, prefer_offline?: boolean, allow_remote_fallback?: boolean) =>
    invoke<SaveEncryptResponse>("save_encrypt_yaml_auto", { req: { steamid, yaml_text, prefer_offline, allow_remote_fallback } }),

  writeBinaryFile: (path: string, bytes: number[] | Uint8Array) =>
    invoke<void>("write_binary_file", { path, bytes: Array.from(bytes as any) }),
};


export type AppConfig = { prefer_offline: boolean; allow_remote_fallback: boolean; steam_id: string | null; reopen_last_on_launch: boolean; last_opened_sav_path: string | null; recent_sav_paths: string[]; recent_yaml_paths: string[] };

export const configEngine = {
  get: () => invoke<AppConfig>("get_app_config"),
  set: (cfg: AppConfig) => invoke<void>("set_app_config", { cfg }),
  addRecentSav: (path: string) => invoke<AppConfig>("add_recent_sav", { path }),
  addRecentYaml: (path: string) => invoke<AppConfig>("add_recent_yaml", { path }),
  setSteamId: (steam_id: string | null) => invoke<AppConfig>("set_steam_id", { steamId: steam_id }),
};


export type SavProbeResponse = {
  path: string;
  file_size: number;
  sha256: string;
  first16_hex: string;
  first16_ascii: string;
  magic_guess: string;
};

export const probeEngine = {
  savProbeFile: (path: string) => invoke<SavProbeResponse>("sav_probe_file", { path }),
};


export type GameDataUpdateResponse = {
  updated: boolean;
  source: string;
  sha256: string;
  bytes: number;
  cached_path: string;
};

export const gameDataEngine = {
  updateOnStart: () => invoke<GameDataUpdateResponse>("game_data_update_on_start"),
  loadCached: () => invoke<string>("game_data_load_cached"),
};


export type SavePlanSlotsRequest = { yaml_text: string; target: string; count: number; start_from?: number | null; max_scan?: number | null };
export type SavePlanSlotsResponse = { target: string; slots: number[]; first_slot: number; scanned_up_to: number };

export const slotPlanEngine = {
  planFreeSlots: (req: SavePlanSlotsRequest) => invoke<SavePlanSlotsResponse>("save_plan_free_slots", { req }),
};

export type SaveClearSlotsRequest = { yaml_text: string; target: string; start_slot: number; end_slot: number };
export type SaveClearSlotsResponse = { yaml_text: string; removed: number };

export const slotToolsEngine = {
  importSlots: (req: SaveImportSlotsRequest) => invoke<SaveImportSlotsResponse>("save_import_slots", { req }),
  exportSlotsRange: (req: SaveExportSlotsRequest) => invoke<SaveExportSlotsResponse>("save_export_slots_range", { req }),
  compactSlots: (req: SaveCompactSlotsRequest) => invoke<SaveCompactSlotsResponse>("save_compact_slots", { req }),
  clearSlotsRange: (req: SaveClearSlotsRequest) => invoke<SaveClearSlotsResponse>("save_clear_slots_range", { req }),
};

export type SaveCompactSlotsRequest = { yaml_text: string; target: string; start_from?: number | null; preserve_order?: boolean | null };
export type SaveCompactSlotsResponse = { yaml_text: string; moved: number; new_count: number; start_from: number };

export type SaveExportSlotsRequest = { yaml_text: string; target: string; start_slot: number; end_slot: number };
export type ExportedSlotEntry = { slot: number; value: string };
export type SaveExportSlotsResponse = { target: string; entries: ExportedSlotEntry[]; count: number };

export type SaveImportSlotsRequest = { yaml_text: string; target: string; entries: ExportedSlotEntry[]; start_slot?: number | null; skip_occupied?: boolean | null };
export type SaveImportSlotsResponse = { yaml_text: string; placed: number; first_slot: number };
