import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppLayout } from "./app/layout";
import { ExportDrawer } from "./ui/ExportDrawer";
import { useExportStore } from "./app/outputStore";

import { BrickRollPage } from "./pages/BrickRoll";
import { BuilderPage } from "./pages/Builder";
import { SaveEditorPage } from "./pages/SaveEditor";
import { BulkToolsPage } from "./pages/BulkTools";
import { SettingsPage } from "./pages/Settings";
import { SaveInspectorPage } from "./pages/SaveInspector";
import { PartsBrowserPage } from "./pages/PartsBrowser";

export default function App() {
  const nav = useNavigate();
  const toast = useToast();
  const gdCtx = useGameData();

  useEffect(() => {
    (async () => {
      try {
        const gd = await gameDataEngine.updateOnStart();
        if (gd.updated) {
          toast(`Game data updated (${(gd.bytes/1024/1024).toFixed(1)} MB).`);
        }
        try {
          const txt = await gameDataEngine.loadCached();
          gdCtx.setRaw(txt);
        } catch {
          // ignore
        }
      } catch (e:any) {
        toast('Game data update failed (using cache if available).', 'error');
        try {
          const txt = await gameDataEngine.loadCached();
          gdCtx.setRaw(txt);
        } catch {
          // no cache
        }
      }
    })();

    (async () => {
      try {
        const cfg = await configEngine.get();
        if (cfg.reopen_last_on_launch && cfg.last_opened_sav_path) {
          if (cfg.steam_id) {
            nav(`/save?open=${encodeURIComponent(cfg.last_opened_sav_path)}`);
          } else {
            nav(`/settings?needSteam=1&next=${encodeURIComponent(cfg.last_opened_sav_path)}`);
          }
        }
      } catch {
        // ignore
      }
    })();
  }, []);

  const visible = useExportStore((s) => s.visible);
  const setVisible = useExportStore((s) => s.setVisible);

  return (
    <BrowserRouter>
      <AppLayout onToggleExport={() => setVisible(!visible)}>
        <Routes>
          <Route path="/" element={<BrickRollPage />} />
          <Route path="/builder" element={<BuilderPage />} />
          <Route path="/save" element={<SaveEditorPage />} />
          <Route path="/bulk" element={<BulkToolsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/inspect" element={<SaveInspectorPage />} />
          <Route path="/parts" element={<PartsBrowserPage />} />
        </Routes>
      </AppLayout>

      <ExportDrawer />
    </BrowserRouter>
  );
}
