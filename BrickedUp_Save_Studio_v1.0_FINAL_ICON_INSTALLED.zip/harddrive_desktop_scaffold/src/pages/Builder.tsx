import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Textarea } from "../ui/Textarea";
import { engine } from "../app/engine";
import { useOutputStore } from "../app/outputStore";
import { usePresetStore } from "../app/presetStore";
import { useToast } from "../ui/Toast";

export function BuilderPage() {
  const [code, setCode] = useState("");
  const setOutputs = useOutputStore((s) => s.setOutputs);
  const preset = usePresetStore((s) => s.preset);
  const patchPreset = usePresetStore((s) => s.patchPreset);
  const setPreset = usePresetStore((s) => s.setPreset);
  const toast = useToast();
  const nav = useNavigate();

  function buildDecodedCode() {
    if (!preset) return "";
    const baseTypeId = preset.baseTypeId ?? preset.parts?.[0]?.typeId;
    if (!baseTypeId) return "";
    const level = preset.level ?? 1;
    const seed = preset.seed ?? 0;
    const firmwareLock = !!preset.firmwareLock;

    // group values by typeId
    const byType = new Map<number, number[]>();
    for (const p of preset.parts) {
      // fullId is usually type:value; use the value
      const full = p.fullId;
      let valStr = full;
      if (full.includes(":")) valStr = full.split(":")[1];
      const v = parseInt(valStr, 10);
      if (!Number.isFinite(v)) continue;
      if (v === 0) continue;
      const arr = byType.get(p.typeId) ?? [];
      arr.push(v);
      byType.set(p.typeId, arr);
    }

    const partsBlocks = Array.from(byType.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([tid, vals]) => `{${tid}:[${Array.from(new Set(vals)).join(" ")}]}`)
      .join(" ");

    let code = `${baseTypeId}, 0, 1, ${level}|`;
    if (firmwareLock) code += ` 9, 1|`;
    if (seed || !firmwareLock) code += ` 2, ${seed}||`;
    else code += `|`;
    code += ` ${partsBlocks}|`;

    const skin = (preset.skinCustomizationValue ?? "").trim();
    if (skin) code += ` "c", ${skin}|`;
    return code;
  }

  function generateDecoded() {
    const code = buildDecodedCode();
    if (!code) {
      toast("Pick a Type ID and add parts first.", "error");
      return;
    }
    patchPreset({ decodedCode: code });
    toast("Forged item code.");
  }
  const nav = useNavigate();

  async function parse() {
    const res = await engine.parseWeaponCode(code);
    setOutputs({
      deserialized: res.normalized ?? "",
      serialized: res.serialized ?? "",
      breakdown: res.breakdown ?? "",
    });
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div>
        <div className="text-2xl font-black">🧱 BrickedUp Builder</div>
        <div className="mt-1 text-sm text-slate-600">
          New builder UI will go here. For now, parse/normalize a code and display output.
        </div>
      </div>

      <Card className="p-4 space-y-3">
        <div className="text-xs font-bold text-slate-500">Paste code</div>
        <Textarea rows={6} value={code} onChange={(e) => setCode(e.target.value)} placeholder="Paste an item/weapon code..." />
        <div className="flex gap-2">
          <Button onClick={parse}>🔍 Parse</Button>
          <Button variant="secondary" onClick={() => setCode("")}>Clear</Button>
        </div>
              </Card>

      {preset && (
        <Card className="p-4 space-y-3">
          <div className="flex items-end justify-between gap-2">
            <div>
              <div className="text-sm font-black">🧩 Selected preset</div>
              <div className="text-xs text-slate-500">{preset.label ?? "(no label)"} • {preset.parts.length} parts</div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => { nav("/save"); toast("Sent preset to Save Editor."); }}>
                Send to Save Editor
              </Button>
              <Button
                variant="secondary"
                onClick={() => {
                  const lines = preset.parts.map((p) => p.spawnCode).filter((x): x is string => !!x && x.trim().length > 0);
                  navigator.clipboard.writeText(lines.join("\n"));
                  toast("Copied preset spawn codes.");
                }}
              >
                Copy Spawn Codes
              </Button>
              <Button variant="secondary" onClick={() => { setPreset(null); toast("Cleared preset."); }}>
                Clear Preset
              </Button>
            </div>
          </div>

          
<div className="grid gap-3 md:grid-cols-5">
  <div>
    <div className="text-xs font-bold text-slate-500">Base Type ID</div>
    <Input
      value={String(preset.baseTypeId ?? "")}
      onChange={(e) => patchPreset({ baseTypeId: e.target.value ? Number(e.target.value) : null })}
      placeholder="e.g. 1310"
    />
  </div>
  <div>
    <div className="text-xs font-bold text-slate-500">Level</div>
    <Input value={String(preset.level ?? 1)} onChange={(e) => patchPreset({ level: Number(e.target.value) })} />
  </div>
  <div>
    <div className="text-xs font-bold text-slate-500">Seed</div>
    <Input value={String(preset.seed ?? 0)} onChange={(e) => patchPreset({ seed: Number(e.target.value) })} />
  </div>
  <div className="flex items-end gap-2">
    <label className="flex items-center gap-2 text-sm text-slate-700">
      <input type="checkbox" checked={!!preset.firmwareLock} onChange={(e) => patchPreset({ firmwareLock: e.target.checked })} />
      Firmware lock
    </label>
  </div>
  <div>
    <div className="text-xs font-bold text-slate-500">Skin (optional)</div>
    <Input value={preset.skinCustomizationValue ?? ""} onChange={(e) => patchPreset({ skinCustomizationValue: e.target.value || null })} placeholder="number" />
  </div>
</div>

<div className="flex flex-wrap gap-2">
  <Button onClick={generateDecoded}>Forge Item Code</Button>
  <Button
    variant="secondary"
    onClick={() => {
      if (!preset.decodedCode) return toast("Generate decoded code first.", "error");
      navigator.clipboard.writeText(preset.decodedCode);
      toast("Copied item code.");
    }}
  >
    Copy Item Code
  </Button>
  <Button
    onClick={() => {
      if (!preset.decodedCode) return toast("Generate decoded code first.", "error");
      nav("/save?tab=apply");
      toast("Send to Inventory Manager → Serialize & Apply and paste decoded code.");
    }}
    variant="secondary"
  >
    Send to Inventory Manager
  </Button>
</div>

{preset.decodedCode && (
  <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
    <div className="text-xs font-bold text-slate-500">Item code</div>
    <div className="mt-1 font-mono text-xs break-all">{preset.decodedCode}</div>
  </div>
)}

<div className="max-h-[420px] overflow-auto rounded-lg border border-slate-200">
            {preset.parts.map((p) => (
              <div key={p.fullId} className="border-b border-slate-200 bg-white p-3">
                <div className="text-xs font-bold text-slate-500">{p.partType ?? "part"} • {p.category ?? ""}</div>
                <div className="mt-1 text-sm font-black">{p.name}</div>
                <div className="mt-1 font-mono text-[11px] break-all text-slate-600">{p.fullId}</div>
                {p.spawnCode && <div className="mt-2 font-mono text-xs break-all text-slate-700">{p.spawnCode}</div>}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
