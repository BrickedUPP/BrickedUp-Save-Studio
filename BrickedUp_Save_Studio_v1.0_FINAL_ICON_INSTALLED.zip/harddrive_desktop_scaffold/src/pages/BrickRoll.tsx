import React, { useState } from "react";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Textarea } from "../ui/Textarea";
import { engine } from "../app/engine";
import { useOutputStore } from "../app/outputStore";

export function BrickRollPage() {
  const [seed, setSeed] = useState("1");
  const [intensity, setIntensity] = useState("100");
  const [baseCode, setBaseCode] = useState("");
  const setOutputs = useOutputStore((s) => s.setOutputs);

  async function roll() {
    const res = await engine.brickRoll({
      seed: Number(seed) || 1,
      intensity: Number(intensity) || 100,
      baseCode: baseCode.trim() || null,
    });
    setOutputs({
      deserialized: res.deserialized ?? "",
      serialized: res.serialized ?? "",
      breakdown: res.breakdown ?? "",
    });
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div>
        <div className="text-2xl font-black">🎲 Brick Roll</div>
        <div className="mt-1 text-sm text-slate-600">
          One-button chaos. New UI, same concept — engine will generate a build.
        </div>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <div className="mb-1 text-xs font-bold text-slate-500">Seed</div>
            <Input value={seed} onChange={(e) => setSeed(e.target.value)} />
          </div>
          <div>
            <div className="mb-1 text-xs font-bold text-slate-500">Stack Intensity</div>
            <Input value={intensity} onChange={(e) => setIntensity(e.target.value)} />
          </div>
          <div className="flex items-end">
            <Button className="w-full" onClick={roll}>🎲 Roll</Button>
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1 text-xs font-bold text-slate-500">Optional base code to remix</div>
          <Textarea rows={4} value={baseCode} onChange={(e) => setBaseCode(e.target.value)} placeholder="Paste a weapon code here..." />
        </div>
      </Card>
    </div>
  );
}
