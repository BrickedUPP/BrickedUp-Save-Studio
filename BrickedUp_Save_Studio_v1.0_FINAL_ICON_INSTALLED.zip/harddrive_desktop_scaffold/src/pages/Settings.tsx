import React, { useEffect, useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { useToast } from "../ui/Toast";
import { configEngine, type AppConfig } from "../app/engine";

export function SettingsPage() {
  const [searchParams] = useSearchParams();
  const nav = useNavigate();
  const toast = useToast();
  const [cfg, setCfg] = useState<AppConfig>({ prefer_offline: false, allow_remote_fallback: true, steam_id: null, reopen_last_on_launch: false, last_opened_sav_path: null, recent_sav_paths: [], recent_yaml_paths: [] });
  const [loaded, setLoaded] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    if (searchParams.get('needSteam') === '1') {
      toast('Steam/Epic ID is required to decrypt/encrypt .sav files. Please enter it below.', 'error');
    }

    (async () => {
      try {
        const c = await configEngine.get();
        setCfg(c);
      } catch {
        // keep defaults
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  async function save() {
    setStatus(null);
    await configEngine.set(cfg);
    setStatus("Saved.");
    setTimeout(() => setStatus(null), 1500);
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div>
        <div className="text-2xl font-black">⚙️ Settings</div>
        <div className="mt-1 text-sm text-slate-600">Long-term behavior toggles.</div>
      </div>

      <Card className="p-4 space-y-3">
        <div className="text-xs font-bold text-slate-500">Steam/Epic ID (stored locally, optional)</div>
        <Input value={cfg.steam_id ?? ""} onChange={(e) => setCfg({ ...cfg, steam_id: e.target.value || null })} placeholder="7656119..." />

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={cfg.prefer_offline}
            onChange={(e) => setCfg({ ...cfg, prefer_offline: e.target.checked })}
            disabled={!loaded}
          />
          Prefer offline codec (when available)
        </label>

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={cfg.allow_remote_fallback}
            onChange={(e) => setCfg({ ...cfg, allow_remote_fallback: e.target.checked })}
            disabled={!loaded}
          />
          Allow remote API fallback (required until offline codec is implemented)
        </label>

        <div className="flex items-center gap-2">
          {searchParams.get("next") && (
            <Button
              variant="secondary"
              onClick={() => {
                const next = searchParams.get("next");
                if (!next) return;
                if (!cfg.steam_id) {
                  toast("Enter Steam/Epic ID first.", "error");
                  return;
                }
                nav(`/save?open=${encodeURIComponent(next)}`);
              }}
            >
              Continue to save
            </Button>
          )}

          <Button onClick={save} disabled={!loaded}>Save Settings</Button>
          {status && <div className="text-sm text-slate-600">{status}</div>}
        </div>
      
  <Card className="p-4 space-y-3">
        <div className="text-xs font-bold text-slate-500">Steam/Epic ID (stored locally, optional)</div>
        <Input value={cfg.steam_id ?? ""} onChange={(e) => setCfg({ ...cfg, steam_id: e.target.value || null })} placeholder="7656119..." />

    <div className="text-sm font-black">Recent files</div>

    <div className="text-xs font-bold text-slate-500">Recent .sav (click to reopen in Save Editor)</div>
    <div className="space-y-1">
      {cfg.recent_sav_paths.length === 0 && <div className="text-sm text-slate-500">(none)</div>}
      {cfg.recent_sav_paths.slice(0, 10).map((p) => (
        <div key={p} className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="truncate text-xs font-mono">{p}</div>
          <div className="flex gap-2">
                        <Button variant="secondary" onClick={() => navigator.clipboard.writeText(p)}>Copy</Button>
                        <Link to={`/save?open=${encodeURIComponent(p)}`}><Button>Reopen</Button></Link>
                      </div>
        </div>
      ))}
    </div>

    <div className="text-xs font-bold text-slate-500 mt-3">Recent YAML</div>
    <div className="space-y-1">
      {cfg.recent_yaml_paths.length === 0 && <div className="text-sm text-slate-500">(none)</div>}
      {cfg.recent_yaml_paths.slice(0, 10).map((p) => (
        <div key={p} className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
          <div className="truncate text-xs font-mono">{p}</div>
          <div className="flex gap-2">
                        <Button variant="secondary" onClick={() => navigator.clipboard.writeText(p)}>Copy</Button>
                        <Link to={`/save?open=${encodeURIComponent(p)}`}><Button>Reopen</Button></Link>
                      </div>
        </div>
      ))}
    </div>
  </Card>
</div>

  );
}
