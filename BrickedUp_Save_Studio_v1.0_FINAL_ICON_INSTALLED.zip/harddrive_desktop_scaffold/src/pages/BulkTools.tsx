import React, { useState } from "react";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Textarea } from "../ui/Textarea";
import { engine } from "../app/engine";

export function BulkToolsPage() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [status, setStatus] = useState<{ ok: number; failed: number } | null>(null);
  const [busy, setBusy] = useState(false);

  async function doDecode() {
    setBusy(true);
    try {
      const res = await engine.bulkDecode(input);
      setOutput(res.output_lines.join("\n"));
      setStatus({ ok: res.ok, failed: res.failed });
    } finally {
      setBusy(false);
    }
  }

  async function doEncode() {
    setBusy(true);
    try {
      const res = await engine.bulkEncode(input);
      setOutput(res.output_lines.join("\n"));
      setStatus({ ok: res.ok, failed: res.failed });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div>
        <div className="text-2xl font-black">🔁 Bulk Tools</div>
        <div className="mt-1 text-sm text-slate-600">
          Convert lists of serials. Accepts Base85 (@Ug...), decoded lines, YAML snippets, or JS object snippets.
        </div>
      </div>

      <Card className="p-4 space-y-3">
        <div className="text-xs font-bold text-slate-500">Input</div>
        <Textarea rows={10} value={input} onChange={(e) => setInput(e.target.value)} placeholder="Paste serials or YAML here..." />
        <div className="flex flex-wrap gap-2">
          <Button onClick={doDecode} disabled={busy}>⬇️ Base85 → Decoded</Button>
          <Button onClick={doEncode} variant="secondary" disabled={busy}>⬆️ Decoded → Base85</Button>
          <Button onClick={() => { setInput(''); setOutput(''); setStatus(null); }} variant="secondary">Clear</Button>
        </div>
        {status && (
          <div className="text-sm text-slate-700">
            Done. OK: <b>{status.ok}</b> • Failed: <b>{status.failed}</b>
          </div>
        )}
      </Card>

      <Card className="p-4 space-y-2">
        <div className="text-xs font-bold text-slate-500">Output</div>
        <Textarea rows={10} value={output} readOnly />
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => navigator.clipboard.writeText(output)}>📋 Copy Output</Button>
        </div>
      </Card>
    </div>
  );
}
