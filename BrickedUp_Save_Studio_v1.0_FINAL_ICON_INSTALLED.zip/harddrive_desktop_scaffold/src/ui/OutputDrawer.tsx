import React from "react";
import { Button } from "./Button";
import { Textarea } from "./Textarea";
import { useOutputStore } from "../app/outputStore";

export function OutputDrawer() {
  const { visible, setVisible, deserialized, serialized, breakdown } = useOutputStore();

  if (!visible) return null;

  return (
    <div className="fixed right-4 top-4 z-50 h-[calc(100vh-2rem)] w-[420px] rounded-2xl border border-slate-200 bg-white shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <div className="text-sm font-black">📦 Output</div>
        <Button variant="ghost" onClick={() => setVisible(false)}>✕</Button>
      </div>

      <div className="flex h-full flex-col gap-4 overflow-auto p-4 pb-28">
        <section>
          <div className="mb-2 text-xs font-bold tracking-wider text-slate-500">DESERIALIZED</div>
          <Textarea value={deserialized} readOnly rows={6} />
        </section>
        <section>
          <div className="mb-2 text-xs font-bold tracking-wider text-slate-500">SERIAL (BASE85)</div>
          <Textarea value={serialized} readOnly rows={4} />
        </section>
        <section>
          <div className="mb-2 text-xs font-bold tracking-wider text-slate-500">BREAKDOWN</div>
          <Textarea value={breakdown} readOnly rows={10} />
        </section>
      </div>

      <div className="absolute bottom-0 left-0 right-0 border-t border-slate-200 bg-white p-4">
        <div className="flex gap-2">
          <Button
            className="flex-1"
            variant="secondary"
            onClick={() => navigator.clipboard.writeText(deserialized || "")}
          >
            📋 Copy Code
          </Button>
          <Button
            className="flex-1"
            variant="secondary"
            onClick={() => navigator.clipboard.writeText(serialized || "")}
          >
            📋 Copy Serial
          </Button>
        </div>
      </div>
    </div>
  );
}
