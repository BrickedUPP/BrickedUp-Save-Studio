import React from "react";
import { useThemeStore, type ThemeId } from "../app/theme";

const THEMES: { id: ThemeId; label: string; emoji: string }[] = [
  { id: "default", label: "Classic", emoji: "✨" },
  { id: "obsidian", label: "Obsidian", emoji: "🖤" },
  { id: "neon", label: "Neon", emoji: "🟢" },
  { id: "rose", label: "Rose", emoji: "🌹" },
];

export function ThemeToggle() {
  const theme = useThemeStore((s) => s.theme);
  const setTheme = useThemeStore((s) => s.setTheme);

  return (
    <div className="flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2 shadow-sm">
      <div className="text-xs font-bold text-subtle">Theme</div>
      <select
        value={theme}
        onChange={(e) => setTheme(e.target.value as ThemeId)}
        className="rounded-lg border border-border bg-surface px-2 py-1 text-sm text-fg outline-none focus:ring-2 focus:ring-ring"
      >
        {THEMES.map((t) => (
          <option key={t.id} value={t.id}>
            {t.emoji} {t.label}
          </option>
        ))}
      </select>
    </div>
  );
}
