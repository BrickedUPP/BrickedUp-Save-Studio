import { useEffect, useMemo, useState } from 'react';
import { engine, type Weapon } from '../app/engine';

export default function App() {
  const [engineVersion, setEngineVersion] = useState<string>('…');

  const [code, setCode] = useState('');
  const [weapon, setWeapon] = useState<Weapon | null>(null);
  const [weaponError, setWeaponError] = useState<string | null>(null);

  const [bulkText, setBulkText] = useState('');
  const [bulkSerials, setBulkSerials] = useState<string[]>([]);
  const [bulkError, setBulkError] = useState<string | null>(null);

  useEffect(() => {
    engine
      .version()
      .then(setEngineVersion)
      .catch((e) => setEngineVersion(String(e)));
  }, []);

  const canParse = useMemo(() => code.trim().length > 0, [code]);

  async function onParseWeapon() {
    setWeaponError(null);
    setWeapon(null);
    try {
      const w = await engine.parseWeaponCode(code);
      setWeapon(w);
    } catch (e) {
      setWeaponError(String(e));
    }
  }

  async function onParseBulk() {
    setBulkError(null);
    setBulkSerials([]);
    try {
      const serials = await engine.parseBulkInput(bulkText);
      setBulkSerials(serials);
    } catch (e) {
      setBulkError(String(e));
    }
  }

  return (
    <div style={{ padding: 20, fontFamily: 'system-ui, Segoe UI, sans-serif' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <h1 style={{ margin: 0 }}>The Hard Drive — Desktop (Rebuild)</h1>
        <span style={{ opacity: 0.7 }}>Engine: {engineVersion}</span>
      </div>

      <p style={{ opacity: 0.8, maxWidth: 900 }}>
        This is the new desktop program foundation: brand‑new UI (placeholder), and a Rust engine
        exposed via a small, stable command API. The legacy HTML is used only as a behavior reference.
      </p>

      <section style={{ marginTop: 24 }}>
        <h2>Weapon Code → Parse (placeholder)</h2>
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Paste a code / serial here…"
          rows={4}
          style={{ width: '100%', maxWidth: 900 }}
        />
        <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
          <button onClick={onParseWeapon} disabled={!canParse}>
            Parse
          </button>
        </div>

        {weaponError && (
          <div style={{ marginTop: 8, color: 'crimson' }}>
            <strong>Error:</strong> {weaponError}
          </div>
        )}

        {weapon && (
          <pre style={{ marginTop: 8, background: '#111', color: '#eee', padding: 12, maxWidth: 900 }}>
            {JSON.stringify(weapon, null, 2)}
          </pre>
        )}
      </section>

      <section style={{ marginTop: 24 }}>
        <h2>Bulk Paste → Extract Serials (implemented)</h2>
        <textarea
          value={bulkText}
          onChange={(e) => setBulkText(e.target.value)}
          placeholder="Paste YAML, JS objects, or raw @Ug... lines…"
          rows={6}
          style={{ width: '100%', maxWidth: 900 }}
        />
        <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
          <button onClick={onParseBulk} disabled={bulkText.trim().length === 0}>
            Extract Serials
          </button>
          <span style={{ opacity: 0.7 }}>Found: {bulkSerials.length}</span>
        </div>

        {bulkError && (
          <div style={{ marginTop: 8, color: 'crimson' }}>
            <strong>Error:</strong> {bulkError}
          </div>
        )}

        {bulkSerials.length > 0 && (
          <pre style={{ marginTop: 8, background: '#111', color: '#eee', padding: 12, maxWidth: 900 }}>
            {bulkSerials.join('\n')}
          </pre>
        )}
      </section>

      <section style={{ marginTop: 24, opacity: 0.85, maxWidth: 900 }}>
        <h2>Next</h2>
        <ul>
          <li>Port real parse/serialize logic into Rust (engine).</li>
          <li>Implement Brick Roll command(s).</li>
          <li>Implement save YAML transforms (equipped/backpack/lost loot operations).</li>
          <li>Replace this placeholder UI with the new designed UI (React + component library).</li>
        </ul>
      </section>
    </div>
  );
}
