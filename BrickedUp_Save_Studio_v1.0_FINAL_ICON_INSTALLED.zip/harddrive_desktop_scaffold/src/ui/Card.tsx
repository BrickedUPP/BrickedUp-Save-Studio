import React from "react";

export function Card(props: React.HTMLAttributes<HTMLDivElement>) {
  const { className = "", ...rest } = props;
  return (
    <div
      {...rest}
      className={["rounded-2xl border border-border bg-surface shadow-soft", className].join(" ")}
    />
  );
}
