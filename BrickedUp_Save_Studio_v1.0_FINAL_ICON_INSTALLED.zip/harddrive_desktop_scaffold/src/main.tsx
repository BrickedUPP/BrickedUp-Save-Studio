import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { ToastProvider } from "./ui/Toast";
import { GameDataProvider } from "./app/gameData";
import { ThemeProvider } from "./app/theme";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ThemeProvider><ToastProvider><GameDataProvider><App /></GameDataProvider></ToastProvider></ThemeProvider>
  </React.StrictMode>
);
