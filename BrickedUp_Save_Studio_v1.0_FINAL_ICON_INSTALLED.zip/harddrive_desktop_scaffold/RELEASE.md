# BrickedUp Save Studio — Release checklist

## Preflight
- [ ] Update version in:
  - `src-tauri/tauri.conf.json` (`package.version`)
  - `package.json` (`version`)
  - `src-tauri/Cargo.toml` (`package.version`)
- [ ] `npm install`
- [ ] `npm run lint`
- [ ] `npm run build`

## Build (Windows)
- [ ] `npm run tauri build`
- Output artifacts are in:
  - `src-tauri/target/release/bundle/`
    - NSIS installer (if enabled)
    - MSI (if enabled)
    - Standalone exe (varies)

## Smoke test
- [ ] Launch app
- [ ] Open `.sav` → decrypt → YAML loads
- [ ] Modify YAML (apply items) → encrypt → `.sav`
- [ ] Confirm recent-files + backups work
- [ ] Confirm parts cache refresh on startup works (online/offline)

## Release notes
Use `CHANGELOG.md`.

