use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OfflineDecodeResult {
    pub yaml_text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OfflineEncodeResult {
    pub sav_bytes: Vec<u8>,
}

/// Offline save decoder/encoder (planned).
///
/// Long-term goal:
/// - Read .sav bytes
/// - Decrypt/decompress/parse into YAML text
/// - Encode YAML back to the exact .sav binary format
///
/// Status: scaffold only.
///
/// Notes:
/// - The current desktop app uses the legacy remote API for decrypt/encrypt so it works today.
/// - This module is the replacement path so the app can run 100% offline.
pub fn decode_offline(_sav_bytes: &[u8], _steamid: &str) -> Result<OfflineDecodeResult, String> {
    Err("Offline save decode not implemented yet (scaffold in place).".to_string())
}

pub fn encode_offline(_yaml_text: &str, _steamid: &str) -> Result<OfflineEncodeResult, String> {
    Err("Offline save encode not implemented yet (scaffold in place).".to_string())
}
