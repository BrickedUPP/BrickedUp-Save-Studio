# BrickedUp Save Studio
Save & Inventory Editor • by BRICKEDNLOADED

Built tough for real saves.

## Development
- `npm install`
- `npm run tauri dev`

## Build (Windows)
- `npm run tauri build`


Hard Drive Desktop (Windows-only)
================================

This is a fresh desktop rebuild using:
- Tauri (Rust backend/engine)
- React + TypeScript (new UI)
- Tailwind (fast, consistent styling)
- Zustand (output drawer state)

Run (dev)
---------
1) Install Node.js (LTS)
2) Install Rust toolchain
3) From project root:

    npm install
    npm run tauri dev

Build (Windows installer)
-------------------------
    npm run tauri build

Architecture
------------
- src-tauri/src/lib.rs: Rust commands (engine surface)
- src/app/engine.ts: Typed UI wrapper around the Tauri commands
- src/pages/*: New screens (Brick Roll / Builder / Save Editor)
- src/ui/OutputDrawer.tsx: Persistent output drawer

Next steps
----------
- Implement true weapon parse/serialize in Rust engine modules
- Implement full Brick Roll generator in Rust
- Implement Save Editor operations (decode/encode, slot edits, mass tools)


Temporary note
--------------
Serial serialize/deserialize currently uses the same remote API as the legacy HTML (borderlands.be/nicnl). This will be replaced with an offline Rust implementation.

File dialogs
------------
Uses @tauri-apps/plugin-dialog for native open/save dialogs and Rust commands for disk IO.


## Quick build (Windows)
If you just want the EXE/installer without remembering commands:

- `tools\build_windows.bat`
- or `powershell -ExecutionPolicy Bypass -File tools\build_windows.ps1`

Outputs are typically under:
- `src-tauri\target\release\bundle\`
