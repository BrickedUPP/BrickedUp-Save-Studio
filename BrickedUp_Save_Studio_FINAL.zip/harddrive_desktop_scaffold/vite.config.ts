import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Note: Tauri uses a fixed port in development (default 1420 in many templates).
// We keep it stable to avoid issues with the Rust side expecting a known dev server URL.
export default defineConfig({
  plugins: [react()],
  clearScreen: false,
  server: {
    strictPort: true,
    port: 1420
  }
});
