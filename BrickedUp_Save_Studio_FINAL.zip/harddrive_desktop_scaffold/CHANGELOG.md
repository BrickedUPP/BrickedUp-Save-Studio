# Changelog

## v1.0.0
- BrickedUp Save Studio initial release.
- Inventory Manager: decrypt/encrypt `.sav` offline.
- Vault Tools: clear, optimize, export/import ranges, transfer macro.
- Parts Library + BrickedUp Builder + encode/apply pipeline.
- Theme system (Classic/Obsidian/Neon/Rose).

