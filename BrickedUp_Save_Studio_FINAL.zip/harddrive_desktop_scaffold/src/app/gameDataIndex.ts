export type PartInfo = {
  id: string;
  fullId: string;
  typeId: number;
  name: string;
  spawnCode?: string;
  stats?: any;
  effects?: any;
  partType?: string;
  category?: string;
  context?: string;
  manufacturer?: string;
  weaponType?: string;
  path?: string;
};

export type TypeInfo = {
  id: number;
  name: string;
  category: string;
  manufacturer?: string;
  weaponType?: string;
  // Useful for debugging/search in the UI
  context?: string;
  path?: string;
};

export type GameDataIndex = {
  typeIdMap: Map<number, TypeInfo>;
  partsByTypeId: Map<number, PartInfo[]>;
};

function normalizePartId(rawId: any, typeId: number): string {
  const s = String(rawId);
  if (s.includes(":")) return s;
  return `${typeId}:${s}`;
}

function extractName(part: any, fallback: string): string {
  return (
    part?.name ??
    part?.model_name ??
    part?.spawn_code ??
    part?.code ??
    part?.string ??
    part?.legendary_name ??
    part?.rarity ??
    fallback
  );
}

function extractPartInfo(
  part: any,
  typeId: number,
  partType: string,
  category: string,
  context: string,
  manufacturer?: string,
  weaponType?: string,
  path?: string
): PartInfo | null {
  if (!part || typeof part !== "object") return null;
  const rawId = part.id;
  if (rawId === null || rawId === undefined) return null;

  const partId = String(rawId);
  const fullId = normalizePartId(rawId, typeId);

  // actual typeId may be embedded in id as "type:value"
  let actualTypeId = typeId;
  if (partId.includes(":")) {
    const colon = partId.indexOf(":");
    const extracted = parseInt(partId.slice(0, colon), 10);
    if (!Number.isNaN(extracted)) actualTypeId = extracted;
  }

  return {
    id: partId,
    fullId,
    typeId: actualTypeId,
    name: extractName(part, partId),
    spawnCode: String(part.spawn_code || part.code || part.string || ""),
    stats: part.stats ?? null,
    effects: part.effects ?? null,
    partType,
    category,
    context,
    manufacturer,
    weaponType,
    path,
  };
}

export function buildGameDataIndex(gameData: any): GameDataIndex {
  const typeIdMap = new Map<number, TypeInfo>();
  const partsByTypeId = new Map<number, PartInfo[]>();

  const addType = (t: TypeInfo) => {
    if (!typeIdMap.has(t.id)) typeIdMap.set(t.id, t);
  };
  const addPart = (p: PartInfo) => {
    const arr = partsByTypeId.get(p.typeId) ?? [];
    arr.push(p);
    partsByTypeId.set(p.typeId, arr);
  };

  const walkPartTypes = (partTypes: any, baseTypeId: number, meta: { category: string; context: string; manufacturer?: string; typeGroup?: string; typeName?: string }) => {
    const walk = (node: any, currentPath = "") => {
      for (const [k, v] of Object.entries<any>(node ?? {})) {
        const p = currentPath ? `${currentPath}.${k}` : k;
        if (!v || typeof v !== "object") continue;

        const parts = (v as any).parts;
        if (Array.isArray(parts)) {
          for (const part of parts) {
            const info = extractPartInfo(
              part,
              baseTypeId,
              k,
              meta.category,
              meta.context,
              meta.manufacturer,
              meta.typeName,
              p
            );
            if (info) {
              info.category = meta.category;
              info.context = meta.context;
              info.manufacturer = meta.manufacturer;
              info.weaponType = meta.typeName;
              info.path = p;
              info.partType = k;
              (info as any).typeGroup = meta.typeGroup;
              addPart(info);
            }
          }
        }

        // Recurse into nested objects excluding "parts"
        const vv = { ...(v as any) };
        delete (vv as any).parts;
        if (Object.keys(vv).length) walk(vv, p);
      }
    };
    walk(partTypes, "");
  };

  // Generic scanning: any top-level category with "manufacturers" object.
  // Within each manufacturer, scan any "*_types" object; each entry that contains a numeric "type_id"
  // and an object "part_types" will be indexed.
  for (const [categoryKey, categoryVal] of Object.entries<any>(gameData ?? {})) {
    const manufacturers = categoryVal?.manufacturers;
    if (!manufacturers || typeof manufacturers !== "object") continue;

    for (const [manufacturer, mdata] of Object.entries<any>(manufacturers)) {
      if (!mdata || typeof mdata !== "object") continue;

      for (const [maybeGroupKey, maybeGroupVal] of Object.entries<any>(mdata)) {
        if (!maybeGroupKey.endsWith("_types")) continue;
        if (!maybeGroupVal || typeof maybeGroupVal !== "object") continue;

        const typeGroup = maybeGroupKey; // e.g., weapon_types, shield_types, grenade_types, etc.

        for (const [typeName, tdata] of Object.entries<any>(maybeGroupVal)) {
          const baseTypeId = tdata?.type_id;
          if (typeof baseTypeId === "number") {
            addType({
              id: baseTypeId,
              name: String(typeName),
              category: String(categoryKey),
              context: `${categoryKey}.${manufacturer}.${typeGroup}.${typeName}`,
              manufacturer: String(manufacturer),
              weaponType: String(typeName),
              path: `${categoryKey}.manufacturers.${manufacturer}.${typeGroup}.${typeName}`,
            });
          }
          const partTypes = tdata?.part_types;
          if (typeof baseTypeId === "number" && partTypes && typeof partTypes === "object") {
            walkPartTypes(partTypes, baseTypeId, {
              category: String(categoryKey),
              context: `${categoryKey}.${manufacturer}.${typeGroup}.${typeName}`,
              manufacturer: String(manufacturer),
              typeGroup,
              typeName: String(typeName),
            });
          }
        }
      }
    }
  }

  // Fallback: Some datasets may have top-level "types" without manufacturers.
  // We keep this hook for later once we confirm schema.
  return { typeIdMap, partsByTypeId };
}

