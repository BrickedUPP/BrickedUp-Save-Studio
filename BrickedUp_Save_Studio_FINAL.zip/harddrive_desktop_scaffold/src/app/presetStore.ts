import { create } from "zustand";
import type { PartsPreset, SelectedPart } from "./partsPreset";

export type PresetState = {
  preset: PartsPreset | null;
  setPreset: (p: PartsPreset | null) => void;
  setParts: (parts: SelectedPart[], label?: string, baseTypeId?: number | null) => void;
  patchPreset: (patch: Partial<PartsPreset>) => void;
};

export const usePresetStore = create<PresetState>((set, get) => ({
  preset: null,
  setPreset: (p) => set({ preset: p }),
  setParts: (parts, label, baseTypeId) =>
    set({
      preset: {
        version: 1,
        createdAt: new Date().toISOString(),
        label,
        baseTypeId: baseTypeId ?? null,
        level: 1,
        seed: 0,
        firmwareLock: false,
        skinCustomizationValue: null,
        parts,
        decodedCode: null,
      },
    }),
  patchPreset: (patch) => {
    const cur = get().preset;
    if (!cur) return;
    set({ preset: { ...cur, ...patch } });
  },
}));
