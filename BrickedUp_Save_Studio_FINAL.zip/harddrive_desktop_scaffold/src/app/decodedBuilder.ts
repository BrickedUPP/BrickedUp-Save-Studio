import type { PartsPreset } from "./partsPreset";

/**
 * Build the "decoded" item code string from a PartsPreset.
 * This is the same format used by the original tool's builder pipeline.
 *
 * IMPORTANT: This does not validate part compatibility. It only constructs the code string.
 */
export function buildDecodedCodeFromPreset(preset: PartsPreset | null): string {
  if (!preset) return "";
  const typeId = preset.baseTypeId ?? null;
  if (!typeId || !Number.isFinite(typeId)) return "";

  // Encode parts as "typeId:partId" blocks separated by commas.
  // We keep fullId which is already normalized.
  const partsBlocks = preset.parts
    .map((p) => p.fullId)
    .filter((s) => typeof s === "string" && s.length > 0)
    .join(",");

  if (!partsBlocks) return "";

  const level = Number.isFinite(preset.level ?? NaN) ? Math.max(1, Number(preset.level)) : 1;
  const seed = Number.isFinite(preset.seed ?? NaN) ? Math.max(0, Number(preset.seed)) : 0;
  const firmwareLock = !!preset.firmwareLock;

  // Format matches BuilderPage prior logic.
  let code = `!${typeId} ${level}|`;

  // In the original builder, seed is only emitted when needed.
  if (seed || !firmwareLock) code += ` 2, ${seed}||`;
  else code += `|`;

  code += ` ${partsBlocks}|`;

  const skin = (preset.skinCustomizationValue ?? "").trim();
  if (skin) code += ` "c", ${skin}|`;

  return code;
}
