import type { GameDataIndex, PartInfo } from "./gameDataIndex";
import type { PartsPreset, SelectedPart } from "./partsPreset";

/** Small, deterministic RNG (Mulberry32). */
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rng: () => number, arr: T[]): T | null {
  if (!arr.length) return null;
  const i = Math.floor(rng() * arr.length);
  return arr[Math.max(0, Math.min(arr.length - 1, i))] ?? null;
}


function shuffleInPlace<T>(rng: () => number, arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}


function toSelectedPart(p: PartInfo): SelectedPart {
  return {
    typeId: p.typeId,
    fullId: p.fullId,
    name: p.name,
    spawnCode: p.spawnCode ?? null,
    category: p.category ?? null,
    manufacturer: p.manufacturer ?? null,
    weaponType: p.weaponType ?? null,
    partType: p.partType ?? null,
    path: p.path ?? null,
  };
}

/**
 * "Brick Roll" — robust, no-throw roller.
 *
 * Goal: always produce a syntactically valid decoded code (when game data exists),
 * never crash, and keep outputs deterministic for a given seed.
 *
 * NOTE: This is a compatibility-safe roller (no hard assumptions about category schema).
 * It selects a base Type ID + a handful of parts with high availability in the dataset.
 */
export type RollFamily = "auto" | "weapon" | "shield" | "grenade" | "classmod" | "artifact" | "enhancement";

function familyFromTypeHint(typeId: number): RollFamily {
  // Heuristic: can be extended with real schema tables later.
  // Keep conservative; default weapon.
  // (If you later provide authoritative mappings, replace this.)
  return "weapon";
}

function partMatchesFamily(p: PartInfo, family: RollFamily): boolean {
  if (family === "auto") return true;

  const cat = (p.category ?? "").toLowerCase();
  const pt = (p.partType ?? "").toLowerCase();
  const wt = (p.weaponType ?? "").toLowerCase();
  const path = (p.path ?? "").toLowerCase();
  const name = (p.name ?? "").toLowerCase();

  const hay = `${cat} ${pt} ${wt} ${path} ${name}`;

  const has = (kw: string[]) => kw.some((k) => hay.includes(k));

  if (family === "weapon") return has(["weapon", "barrel", "grip", "magazine", "scope", "underbarrel"]);
  if (family === "shield") return has(["shield", "capacity", "recharge", "amp", "booster"]);
  if (family === "grenade") return has(["grenade", "nade", "explosive", "fuse"]);
  if (family === "classmod") return has(["classmod", "class mod", "mod", "skill"]);
  if (family === "artifact") return has(["artifact", "relic"]);
  if (family === "enhancement") return has(["enhancement", "augment"]);
  return false;
}

/**
 * "Brick Roll" — robust, no-throw roller.
 *
 * Guarantees:
 * - Never throws (caller may still wrap in try/catch).
 * - Deterministic for a given seed.
 * - Family-safe filtering (never intentionally mixes families when family != "auto").
 *
 * NOTE: This is a heuristic roller unless you provide authoritative category schemas.
 * It is designed to be safe and stable, not to exploit unknown compatibility tables.
 */
export function rollPreset(
  index: GameDataIndex,
  opts: { seed: number; intensity: number; baseCode?: string | null; unlockAllParts?: boolean; family?: RollFamily }
): PartsPreset {
  const rng = mulberry32(opts.seed || 1);
  const family: RollFamily = opts.family ?? "auto";

  // Gather all parts once.
  const allParts: PartInfo[] = [];
  for (const parts of index.partsByTypeId.values()) {
    if (Array.isArray(parts)) allParts.push(...parts);
  }

  if (!allParts.length) {
    return {
      version: 1,
      createdAt: new Date().toISOString(),
      label: "Brick Roll",
      seed: opts.seed || 1,
      intensity: opts.intensity || 100,
      baseTypeId: 0,
      level: 1,
      firmwareLock: false,
      skinCustomizationValue: null,
      parts: [],
      decodedCode: null,
      summary: "No parts data loaded.",
    };
  }

  // Filter by family (never mix when family chosen).
  let candidateParts = family === "auto" ? allParts : allParts.filter((p) => partMatchesFamily(p, family));
  if (!candidateParts.length) {
    // Fallback to all parts to avoid hard failure, but keep caller informed.
    candidateParts = allParts;
  }

  // Pick a base typeId with the most candidates in this family (or random if unlockAllParts).
  let bestTypeId: number | null = null;
  let bestCount = -1;

  for (const [typeId, parts] of index.partsByTypeId.entries()) {
    const pool = (parts ?? []).filter((p) => (family === "auto" ? true : partMatchesFamily(p, family)));
    const c = pool.length;
    if (c > bestCount) {
      bestCount = c;
      bestTypeId = typeId;
    }
  }

  if (bestTypeId === null) {
    const first = index.partsByTypeId.keys().next();
    bestTypeId = first && !first.done ? (first.value as number) : 0;
  }

  if (opts.unlockAllParts) {
    const keys = [...index.partsByTypeId.keys()];
    if (keys.length) bestTypeId = keys[Math.floor(rng() * keys.length)] ?? bestTypeId;
  }

  const baseTypeId = bestTypeId ?? 0;

  // Build category pools
  const byCategory = new Map<string, PartInfo[]>();
  for (const p of candidateParts) {
    const key = (p.category ?? p.partType ?? "unknown").toString();
    if (!byCategory.has(key)) byCategory.set(key, []);
    byCategory.get(key)!.push(p);
  }

  // Choose parts: stable order by category name, sample N categories based on intensity.
  const categories = [...byCategory.keys()].sort((a, b) => a.localeCompare(b));
  const target = Math.max(4, Math.min(16, Math.floor((opts.intensity || 100) / 8))); // 4..16
  const chosen: SelectedPart[] = [];
  const usedFullIds = new Set<string>();

  // Shuffle categories deterministically
  const shuffled = categories.slice();
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  for (const cat of shuffled) {
    if (chosen.length >= target) break;
    const pool = byCategory.get(cat) ?? [];
    if (!pool.length) continue;
    const p = pick(rng, pool);
    if (!p) continue;
    if (usedFullIds.has(p.fullId)) continue;
    usedFullIds.add(p.fullId);
    chosen.push(toSelectedPart(p));
  }

  return {
    version: 1,
    createdAt: new Date().toISOString(),
    label: "Brick Roll",
    seed: opts.seed || 1,
    intensity: opts.intensity || 100,
    baseTypeId,
    level: 1,
    firmwareLock: false,
    skinCustomizationValue: null,
    parts: chosen,
    decodedCode: null,
    summary: `Rolled ${chosen.length} parts (${family === "auto" ? "auto" : family}).`,
  };
}

