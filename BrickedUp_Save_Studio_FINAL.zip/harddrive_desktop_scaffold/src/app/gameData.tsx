import React, { createContext, useContext, useMemo, useState } from "react";

export type GameDataState = {
  rawText: string | null;
  json: any | null;
  loaded: boolean;
  error?: string | null;
};

type GameDataCtxValue = GameDataState & {
  setRaw: (text: string) => void;
  clear: () => void;
};

const GameDataCtx = createContext<GameDataCtxValue | null>(null);

export function GameDataProvider({ children }: { children: React.ReactNode }) {
  const [rawText, setRawText] = useState<string | null>(null);
  const [jsonObj, setJsonObj] = useState<any | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const value = useMemo<GameDataCtxValue>(
    () => ({
      rawText,
      json: jsonObj,
      loaded,
      error,
      setRaw: (text) => {
        setRawText(text);
        try {
          setJsonObj(JSON.parse(text));
          setError(null);
        } catch (e: any) {
          setJsonObj(null);
          setError(e?.toString?.() ?? "Failed to parse JSON");
        } finally {
          setLoaded(true);
        }
      },
      clear: () => {
        setRawText(null);
        setJsonObj(null);
        setLoaded(false);
        setError(null);
      },
    }),
    [rawText, jsonObj, loaded, error]
  );

  return <GameDataCtx.Provider value={value}>{children}</GameDataCtx.Provider>;
}

export function useGameData() {
  const ctx = useContext(GameDataCtx);
  if (!ctx) throw new Error("useGameData must be used within GameDataProvider");
  return ctx;
}
