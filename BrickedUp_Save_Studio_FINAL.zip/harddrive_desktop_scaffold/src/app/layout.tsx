import React from "react";
import { NavLink } from "react-router-dom";
import { Button } from "../ui/Button";
import { ThemeToggle } from "../ui/ThemeToggle";

export function AppLayout(props: { children: React.ReactNode; onToggleOutput: () => void }) {
  const { children, onToggleOutput } = props;

  const linkBase =
    "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-colors";
  const active = "bg-accent text-accent-fg";
  const inactive = "text-subtle hover:bg-muted";

  return (
    <div className="min-h-screen bg-app text-fg">
      <div className="flex min-h-screen">
        <aside className="w-64 border-r border-border bg-surface p-4">
          <div className="mb-6">
            <div className="text-xs font-bold tracking-wider text-subtle">BRICKEDUP</div>
            <div className="text-lg font-black tracking-tight">Hard Drive Desktop</div>
            <div className="mt-1 text-xs text-subtle">Windows-only • New UI</div>
          </div>

          <nav className="flex flex-col gap-1">
            <NavLink to="/" end className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              🎲 Brick Roll
            </NavLink>
            <NavLink to="/builder" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              🧱 BrickedUp Builder
            </NavLink>
            <NavLink to="/save" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              💾 Inventory Manager
            </NavLink>
            <NavLink to="/inspect" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              🔬 Save Inspector
            </NavLink>
            <NavLink to="/parts" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              🧩 Parts Library
            </NavLink>
            <NavLink to="/bulk" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              🔁 Bulk Tools
            </NavLink>
            <NavLink to="/settings" className={({ isActive }) => [linkBase, isActive ? active : inactive].join(" ")}>
              ⚙️ Settings
            </NavLink>
          </nav>

          <div className="mt-6 rounded-xl border border-border bg-muted p-3 text-xs text-slate-600">
            <div className="font-bold text-fg">Design goals</div>
            <ul className="mt-2 list-disc space-y-1 pl-4">
              <li>Fresh look and layout</li>
              <li>Engine in Rust</li>
              <li>UI calls commands only</li>
            </ul>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between border-b border-border bg-surface px-6 py-4">
            <div className="min-w-0">
              <div className="truncate text-sm font-bold text-subtle">Hard Drive</div>
              <div>
                <div className="truncate text-xl font-black tracking-tight">BrickedUp Save Studio</div>
                <div className="text-xs text-subtle">Save &amp; Inventory Editor • by BRICKEDNLOADED</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button variant="secondary" onClick={onToggleOutput}>📦 Export</Button>
            </div>
          </header>

          <main className="flex-1 p-6">{children}</main>
        </div>
      </div>
    </div>
  );
}
