export type SelectedPart = {
  typeId: number;
  fullId: string;
  name: string;
  spawnCode?: string | null;
  category?: string | null;
  manufacturer?: string | null;
  weaponType?: string | null;
  partType?: string | null;
  path?: string | null;
};

export type PartsPreset = {
  version: 1;
  createdAt: string;
  label?: string;
  // Builder context (optional): which Type ID this preset is intended for
  baseTypeId?: number | null;
  // Builder options (optional)
  level?: number | null;
  seed?: number | null;
  // Brick Roll option (optional)
  intensity?: number | null;
  firmwareLock?: boolean | null;
  skinCustomizationValue?: string | null;
  parts: SelectedPart[];
  // Generated decoded code (optional)
  decodedCode?: string | null;
  // Informational-only (optional)
  summary?: string | null;
};
