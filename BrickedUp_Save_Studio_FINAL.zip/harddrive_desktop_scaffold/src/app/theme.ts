import React from "react";
import { create } from "zustand";

export type ThemeId = "default" | "obsidian" | "neon" | "rose";

const THEME_KEY = "hd_theme_v1";

function applyThemeToDom(theme: ThemeId) {
  const el = document.documentElement;
  el.classList.remove("theme-obsidian", "theme-neon", "theme-rose");
  if (theme === "obsidian") el.classList.add("theme-obsidian");
  if (theme === "neon") el.classList.add("theme-neon");
  if (theme === "rose") el.classList.add("theme-rose");
}

export type ThemeState = {
  theme: ThemeId;
  setTheme: (t: ThemeId) => void;
  hydrate: () => void;
};

export const useThemeStore = create<ThemeState>((set, get) => ({
  theme: "default",
  setTheme: (t) => {
    set({ theme: t });
    try {
      localStorage.setItem(THEME_KEY, t);
    } catch {
      // ignore
    }
    applyThemeToDom(t);
  },
  hydrate: () => {
    let t: ThemeId = "default";
    try {
      const raw = localStorage.getItem(THEME_KEY);
      if (raw === "default" || raw === "obsidian" || raw === "neon" || raw === "rose") t = raw;
    } catch {
      // ignore
    }
    set({ theme: t });
    applyThemeToDom(t);
  },
}));

export function ThemeProvider(props: { children: React.ReactNode }) {
  // Small inline provider so we don't add another dependency.
  // Hydrates once on app start.
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const hydrate = useThemeStore((s) => s.hydrate);
  // eslint-disable-next-line react-hooks/rules-of-hooks
  React.useEffect(() => hydrate(), [hydrate]);
  // Avoid JSX here because this file is .ts, not .tsx
  return React.createElement(React.Fragment, null, props.children);
}
