import { create } from "zustand";

export type OutputState = {
  visible: boolean;
  deserialized: string;
  serialized: string;
  breakdown: string;
  setVisible: (v: boolean) => void;
  setOutputs: (o: Partial<Pick<OutputState, "deserialized" | "serialized" | "breakdown">>) => void;
};

export const useOutputStore = create<OutputState>((set) => ({
  visible: true,
  deserialized: "",
  serialized: "",
  breakdown: "",
  setVisible: (v) => set({ visible: v }),
  setOutputs: (o) => set(o as any),
}));
