import React from "react";

export function BusyOverlay({ show, label }: { show: boolean; label?: string }) {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="rounded-xl bg-white px-6 py-4 shadow-xl">
        <div className="text-sm font-bold">Working…</div>
        <div className="text-xs text-slate-600">{label ?? "Please wait"}</div>
      </div>
    </div>
  );
}
