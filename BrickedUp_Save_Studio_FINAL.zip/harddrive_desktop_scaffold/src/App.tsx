import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";

import { AppLayout } from "./app/layout";
import { useOutputStore } from "./app/outputStore";
import { useToast } from "./ui/Toast";
import { useGameData } from "./app/gameData";
import { OutputDrawer } from "./ui/OutputDrawer";

import {
  configEngine,
  gameDataEngine,
  guideEngine,
} from "./app/engine";

import { BrickRollPage } from "./pages/BrickRoll";
import { BuilderPage } from "./pages/Builder";
import { SaveEditorPage } from "./pages/SaveEditor";
import { BulkToolsPage } from "./pages/BulkTools";
import { SettingsPage } from "./pages/Settings";
import { SaveInspectorPage } from "./pages/SaveInspector";
import { PartsBrowserPage } from "./pages/PartsBrowser";
import { GuidePage } from "./pages/Guide";

function AppInner() {
  const nav = useNavigate();
  const toast = useToast();
  const gdCtx = useGameData();

  const visible = useOutputStore((s) => s.visible);
  const setVisible = useOutputStore((s) => s.setVisible);

  useEffect(() => {
    // Update (or confirm) cached game data, then load it into memory.
    (async () => {
      try {
        const gd = await gameDataEngine.updateOnStart();
        if (gd.updated) {
          toast(`Game data updated (${(gd.bytes / 1024 / 1024).toFixed(1)} MB).`);
        }
      } catch (e: any) {
        toast("Game data update failed (using cache if available).", "error");
      }

      try {
        const txt = await gameDataEngine.loadCached();
        gdCtx.setRaw(txt);
      } catch {
        // no cache available
      }
    })();

    // Init local guide (offline-first)
    (async () => {
      try {
        await guideEngine.init();
      } catch {
        /* ignore */
      }
    })();

    // Optional: reopen last save on launch
    (async () => {
      try {
        const cfg = await configEngine.get();
        if (cfg.reopen_last_query && cfg.last_sav_path) {
          if (cfg.steam_id) {
            nav(`/save?open=${encodeURIComponent(cfg.last_sav_path)}`);
          } else {
            nav(`/settings?needSteam=1&next=${encodeURIComponent(cfg.last_sav_path)}`);
          }
        }
      } catch {
        // ignore
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <AppLayout onToggleOutput={() => setVisible(!visible)}>
        <Routes>
          <Route path="/" element={<BrickRollPage />} />
          <Route path="/builder" element={<BuilderPage />} />
          <Route path="/save" element={<SaveEditorPage />} />
          <Route path="/bulk" element={<BulkToolsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/inspect" element={<SaveInspectorPage />} />
          <Route path="/parts" element={<PartsBrowserPage />} />
          <Route path="/guide" element={<GuidePage />} />
        </Routes>
      </AppLayout>

      <OutputDrawer />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppInner />
    </BrowserRouter>
  );
}
