import React, { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { useToast } from "../ui/Toast";
import { configEngine, type AppConfig } from "../app/engine";

const DEFAULT_CFG: AppConfig = {
  prefer_offline: false,
  allow_remote_fallback: true,
  steam_id: null,
  reopen_last_query: true,
  last_sav_path: null,
  last_yaml_path: null,
  recent_sav_paths: [],
  recent_yaml_paths: [],
  unlock_all_parts: false,
};

export function SettingsPage() {
  const [searchParams] = useSearchParams();
  const nav = useNavigate();
  const toast = useToast();

  const [cfg, setCfg] = useState<AppConfig>(DEFAULT_CFG);
  const [loaded, setLoaded] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    if (searchParams.get("needSteam") === "1") {
      toast(
        "Steam/Epic ID is required to decrypt/encrypt .sav files. Please enter it below.",
        "error"
      );
    }

    (async () => {
      try {
        const c = await configEngine.get();
        setCfg({ ...DEFAULT_CFG, ...c });
      } catch {
        // keep defaults
      } finally {
        setLoaded(true);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function save() {
    setStatus(null);
    try {
      await configEngine.set(cfg);
      setStatus("Saved.");
      setTimeout(() => setStatus(null), 1500);
    } catch (e: any) {
      toast(e?.toString?.() ?? "Failed to save settings", "error");
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div>
        <div className="text-2xl font-black">⚙️ Settings</div>
        <div className="mt-1 text-sm text-slate-600">Offline/cache behavior & defaults.</div>
      </div>

      <Card className="p-4 space-y-3">
        <div>
          <div className="text-xs font-bold text-slate-500">Steam/Epic ID (stored locally)</div>
          <Input
            value={cfg.steam_id ?? ""}
            onChange={(e) => setCfg({ ...cfg, steam_id: e.target.value || null })}
            placeholder="7656119..."
            disabled={!loaded}
          />
        </div>

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={cfg.prefer_offline}
            onChange={(e) => setCfg({ ...cfg, prefer_offline: e.target.checked })}
            disabled={!loaded}
          />
          Prefer offline codec (when available)
        </label>

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={cfg.allow_remote_fallback}
            onChange={(e) => setCfg({ ...cfg, allow_remote_fallback: e.target.checked })}
            disabled={!loaded}
          />
          Allow remote API fallback (needed until offline codec covers all cases)
        </label>

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={!!cfg.unlock_all_parts}
            onChange={(e) => setCfg({ ...cfg, unlock_all_parts: e.target.checked })}
            disabled={!loaded}
          />
          Unlock all parts (show full parts catalog)
        </label>

        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input
            type="checkbox"
            checked={cfg.reopen_last_query}
            onChange={(e) => setCfg({ ...cfg, reopen_last_query: e.target.checked })}
            disabled={!loaded}
          />
          Reopen last save on launch (if path is known)
        </label>

        <div className="flex items-center gap-2">
          {searchParams.get("next") && (
            <Button
              variant="secondary"
              onClick={() => {
                const next = searchParams.get("next");
                if (!next) return;
                if (!cfg.steam_id) {
                  toast("Enter Steam/Epic ID first.", "error");
                  return;
                }
                nav(`/save?open=${encodeURIComponent(next)}`);
              }}
            >
              Continue to save
            </Button>
          )}

          <Button onClick={save} disabled={!loaded}>
            Save Settings
          </Button>
          {status && <div className="text-sm text-slate-600">{status}</div>}
        </div>
      </Card>

      <Card className="p-4 space-y-3">
        <div className="text-sm font-black">Recent files</div>

        <div>
          <div className="text-xs font-bold text-slate-500">Recent .sav (reopen in Inventory Manager)</div>
          <div className="mt-2 space-y-1">
            {cfg.recent_sav_paths.length === 0 && <div className="text-sm text-slate-500">(none)</div>}
            {cfg.recent_sav_paths.slice(0, 10).map((p) => (
              <div
                key={p}
                className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2"
              >
                <div className="truncate text-xs font-mono">{p}</div>
                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => navigator.clipboard.writeText(p)}>
                    Copy
                  </Button>
                  <Link to={`/save?open=${encodeURIComponent(p)}`}>
                    <Button>Reopen</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="text-xs font-bold text-slate-500 mt-3">Recent YAML / presets</div>
          <div className="mt-2 space-y-1">
            {cfg.recent_yaml_paths.length === 0 && <div className="text-sm text-slate-500">(none)</div>}
            {cfg.recent_yaml_paths.slice(0, 10).map((p) => (
              <div
                key={p}
                className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2"
              >
                <div className="truncate text-xs font-mono">{p}</div>
                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => navigator.clipboard.writeText(p)}>
                    Copy
                  </Button>
                  {/* Save editor can open YAML via its own file picker; we still keep the link handy */}
                  <Link to={`/save`}>
                    <Button>Open Editor</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
