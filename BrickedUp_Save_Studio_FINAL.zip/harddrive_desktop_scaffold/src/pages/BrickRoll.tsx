import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Textarea } from "../ui/Textarea";
import { engine, configEngine, type AppConfig } from "../app/engine";
import { useGameData } from "../app/gameData";
import { buildGameDataIndex } from "../app/gameDataIndex";
import { rollPreset, type RollFamily } from "../app/rollEngine";
import { buildDecodedCodeFromPreset } from "../app/decodedBuilder";
import { useToast } from "../ui/Toast";
import { useOutputStore } from "../app/outputStore";

const FAMILY_OPTIONS: { value: RollFamily; label: string }[] = [
  { value: "auto", label: "Auto (recommended)" },
  { value: "weapon", label: "Weapon" },
  { value: "shield", label: "Shield" },
  { value: "grenade", label: "Grenade" },
  { value: "classmod", label: "Class Mod" },
  { value: "artifact", label: "Artifact" },
  { value: "enhancement", label: "Enhancement" },
];

function loadFamily(): RollFamily {
  const v = (localStorage.getItem("brick_roll_family") ?? "auto") as RollFamily;
  return (FAMILY_OPTIONS.some((o) => o.value === v) ? v : "auto");
}

function saveFamily(v: RollFamily) {
  localStorage.setItem("brick_roll_family", v);
}

export function BrickRollPage() {
  const [seed, setSeed] = useState("1");
  const [intensity, setIntensity] = useState("100");
  const [baseCode, setBaseCode] = useState("");
  const [family, setFamily] = useState<RollFamily>(() => loadFamily());
  const [cfg, setCfg] = useState<AppConfig | null>(null);

  const setOutputs = useOutputStore((s) => s.setOutputs);
  const gameData = useGameData();
  const toast = useToast();

  useEffect(() => {
    let mounted = true;
    configEngine.get().then((c) => { if (mounted) setCfg(c); }).catch(() => { /* ignore */ });
    return () => { mounted = false; };
  }, []);

  const unlockAll = !!cfg?.unlock_all_parts;

  async function roll() {
    try {
      const seedNum = Number.parseInt(seed, 10);
      const intensityNum = Number.parseInt(intensity, 10);

      if (!Number.isFinite(seedNum) || seedNum <= 0) {
        toast("Seed must be a positive integer.", "error");
        return;
      }
      if (!Number.isFinite(intensityNum) || intensityNum < 1 || intensityNum > 100) {
        toast("Intensity must be 1–100.", "error");
        return;
      }

      if (!gameData.loaded || !gameData.json) {
        toast("Game data not loaded yet. Open Settings → Resources and download/refresh game data first.", "error");
        return;
      }

      const idx = buildGameDataIndex(gameData.json);

      const preset = rollPreset(idx, {
        seed: seedNum,
        intensity: intensityNum,
        baseCode: baseCode.trim() ? baseCode.trim() : null,
        unlockAllParts: unlockAll,
        family,
      });

      const decoded = buildDecodedCodeFromPreset(preset);
      let serialized = "";

      if (decoded) {
        const sres = await engine.serializeDecoded(decoded);
        serialized = sres.serial_b85 ?? "";
      }

      setOutputs({
        deserialized: decoded ?? "",
        serialized,
        breakdown: `Brick Roll\nFamily: ${family}\nUnlock all parts: ${unlockAll ? "ON" : "OFF"}\nSeed: ${preset.seed}\nBase Type ID: ${preset.baseTypeId}\nParts: ${preset.parts.length}\n${preset.summary ?? ""}`,
      });

      toast(decoded ? "Brick Roll complete." : "Brick Roll produced no code (data may be incomplete).", decoded ? "success" : "error");
    } catch (e: any) {
      console.error(e);
      toast(`Brick Roll failed safely: ${e?.message ?? String(e)}`, "error");
    }
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <Card className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-black">🎲 Brick Roll</div>
            <div className="text-xs text-subtle">Family-safe rolling. Never mixes guns with shields.</div>
          </div>
          <div className="text-xs text-subtle">
            Unlock all parts: <span className={unlockAll ? "text-accent font-black" : "text-subtle"}>{unlockAll ? "ON" : "OFF"}</span>
          </div>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-5">
          <div>
            <div className="mb-1 text-xs font-bold text-subtle">Seed</div>
            <Input value={seed} onChange={(e) => setSeed(e.target.value)} />
          </div>
          <div>
            <div className="mb-1 text-xs font-bold text-subtle">Intensity (1–100)</div>
            <Input value={intensity} onChange={(e) => setIntensity(e.target.value)} />
          </div>
          <div className="md:col-span-2">
            <div className="mb-1 text-xs font-bold text-subtle">Item family</div>
            <select
              value={family}
              onChange={(e) => { const v = e.target.value as RollFamily; setFamily(v); saveFamily(v); }}
              className="w-full rounded-xl border border-border bg-surface px-3 py-2 text-sm text-fg outline-none focus:ring-2 focus:ring-ring"
            >
              {FAMILY_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <Button className="w-full" onClick={roll}>🎲 Roll</Button>
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1 text-xs font-bold text-subtle">Optional base code to remix</div>
          <Textarea
            rows={4}
            value={baseCode}
            onChange={(e) => setBaseCode(e.target.value)}
            placeholder="Paste an item code here (optional)…"
          />
        </div>
      </Card>
    </div>
  );
}
