import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { open, save } from "@tauri-apps/plugin-dialog";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { useToast } from "../ui/Toast";
import { useGameData } from "../app/gameData";
import { gameDataEngine, fileEngine, configEngine } from "../app/engine";
import { buildGameDataIndex } from "../app/gameDataIndex";
import type { PartsPreset, SelectedPart } from "../app/partsPreset";
import { usePresetStore } from "../app/presetStore";

export function PartsBrowserPage() {
  const gd = useGameData();
  const nav = useNavigate();
  const setPreset = usePresetStore((s) => s.setParts);
  const toast = useToast();

  const [q, setQ] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [selectedTypeId, setSelectedTypeId] = useState<number | null>(null);

  const [selectedParts, setSelectedParts] = useState<SelectedPart[]>([]);
  const [presetLabel, setPresetLabel] = useState("");

  async function reloadFromCache() {
    try {
      const txt = await gameDataEngine.loadCached();
      gd.setRaw(txt);
      toast("Loaded cached game data.");
    } catch (e: any) {
      toast(e?.toString?.() ?? "No cached game data found", "error");
    }
  }

  const index = useMemo(() => (gd.json ? buildGameDataIndex(gd.json) : null), [gd.json]);

  const categories = useMemo(() => {
    if (!index) return [];
    const set = new Set<string>();
    for (const t of index.typeIdMap.values()) {
      if (t.category) set.add(String(t.category));
    }
    return Array.from(set).sort();
  }, [index]);

  const typeRows = useMemo(() => {
    if (!index) return [];
    const query = q.trim().toLowerCase();
    const out = Array.from(index.typeIdMap.values());

    return out
      .filter((t) => {
        if (category !== "all" && String(t.category) !== category) return false;
        if (!query) return true;
        const hay = `${t.id} ${t.name ?? ""} ${t.category ?? ""} ${t.manufacturer ?? ""} ${t.context ?? ""} ${t.path ?? ""}`.toLowerCase();
        return hay.includes(query);
      })
      .sort((a, b) => a.id - b.id)
      .slice(0, 800);
  }, [index, q, category]);

  const partsForSelectedType = useMemo(() => {
    if (!index || selectedTypeId === null) return [];
    return (index.partsByTypeId.get(selectedTypeId) ?? []).slice().sort((a, b) => (a.partType ?? "").localeCompare(b.partType ?? ""));
  }, [index, selectedTypeId]);

  function addPart(p: any) {
    const part: SelectedPart = {
      typeId: p.typeId,
      fullId: p.fullId,
      name: p.name,
      spawnCode: p.spawnCode ?? null,
      category: p.category ?? null,
      manufacturer: p.manufacturer ?? null,
      weaponType: p.weaponType ?? null,
      partType: p.partType ?? null,
      path: p.path ?? null,
    };
    setSelectedParts((cur) => {
      if (cur.some((x) => x.fullId === part.fullId)) return cur;
      return [...cur, part];
    });
    toast("Added part.");
  }

  function removePart(fullId: string) {
    setSelectedParts((cur) => cur.filter((p) => p.fullId !== fullId));
  }

  function copySelectedSpawnCodes() {
    const lines = selectedParts
      .map((p) => p.spawnCode)
      .filter((x): x is string => !!x && x.trim().length > 0);
    navigator.clipboard.writeText(lines.join("\n"));
    toast("Copied spawn codes.");
  }

  function copySelectedJson() {
    const preset: PartsPreset = {
      version: 1,
      createdAt: new Date().toISOString(),
      label: presetLabel.trim() || undefined,
      parts: selectedParts,
    };
    navigator.clipboard.writeText(JSON.stringify(preset, null, 2));
    toast("Copied preset JSON.");
  }

  async function savePresetToFile() {
    const preset: PartsPreset = {
      version: 1,
      createdAt: new Date().toISOString(),
      label: presetLabel.trim() || undefined,
      parts: selectedParts,
    };
    const p = await save({ defaultPath: (preset.label || "parts_preset") + ".json", filters: [{ name: "JSON", extensions: ["json"] }] });
    if (!p) return;
    await fileEngine.writeTextFile(p, JSON.stringify(preset, null, 2));
    await configEngine.addRecentYaml(p); // reuse yaml recent list for presets
    toast("Saved preset.");
  }

  async function loadPresetFromFile() {
    const p = await open({ multiple: false, filters: [{ name: "JSON", extensions: ["json"] }] });
    if (!p || Array.isArray(p)) return;
    try {
      const res = await fileEngine.readTextFile(p);
      const obj = JSON.parse(res.content) as PartsPreset;
      if (obj.version !== 1 || !Array.isArray(obj.parts)) throw new Error("Invalid preset format");
      setSelectedParts(obj.parts);
      setPresetLabel(obj.label ?? "");
      await configEngine.addRecentYaml(res.path);
      toast("Loaded preset.");
    } catch (e: any) {
      toast(e?.toString?.() ?? "Failed to load preset", "error");
    }
  }

  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-black">🧩 Parts Library</div>
          <div className="mt-1 text-sm text-slate-600">
            Cached game data (updated on start) • Browse Type IDs • Add parts to a preset (export/copy).
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Status:{" "}
            {gd.loaded ? (gd.error ? <span className="text-red-600">{gd.error}</span> : <span className="text-emerald-700">Loaded</span>) : <span>Not loaded</span>}
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={reloadFromCache}>
            ↻ Load Cache
          </Button>
        </div>
      </div>

      <Card className="p-4 space-y-3">
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <div className="text-xs font-bold text-slate-500">Search type IDs / names</div>
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search (id, manufacturer, type, category...)" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-500">Category</div>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setSelectedTypeId(null);
              }}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
            >
              <option value="all">All</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="text-xs text-slate-500">
            <div className="font-bold">Index</div>
            <div>Types: <b>{index ? index.typeIdMap.size : 0}</b></div>
            <div>Parts buckets: <b>{index ? index.partsByTypeId.size : 0}</b></div>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-4 space-y-2 md:col-span-1">
          <div className="text-sm font-black">Type IDs</div>
          <div className="text-xs text-slate-500">Showing up to 800 (filter with search).</div>
          <div className="mt-2 max-h-[520px] overflow-auto rounded-lg border border-slate-200">
            {typeRows.map((t) => {
              const active = selectedTypeId === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setSelectedTypeId(t.id)}
                  className={
                    "w-full border-b border-slate-200 px-3 py-2 text-left hover:bg-slate-50 " +
                    (active ? "bg-slate-100" : "bg-white")
                  }
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-mono text-xs text-slate-700">{t.id}</div>
                    <div className="text-xs text-slate-500">{t.category}</div>
                  </div>
                  <div className="mt-1 text-sm font-black">{t.name}</div>
                  <div className="mt-1 text-xs text-slate-500">
                    {t.manufacturer ? <span className="mr-2">Mfr: <b>{t.manufacturer}</b></span> : null}
                    {t.path ? <span className="font-mono">{t.path}</span> : null}
                  </div>
                </button>
              );
            })}
            {typeRows.length === 0 && <div className="p-3 text-sm text-slate-500">No types found (or data not loaded).</div>}
          </div>
        </Card>

        <Card className="p-4 space-y-2 md:col-span-1">
          <div className="text-sm font-black">Parts</div>
          {!selectedTypeId && <div className="text-sm text-slate-500">Select a Type ID to see its parts.</div>}
          {selectedTypeId !== null && (
            <div className="mt-2 max-h-[520px] overflow-auto rounded-lg border border-slate-200">
              {partsForSelectedType.map((p, idx) => (
                <div key={`${p.fullId}-${idx}`} className="border-b border-slate-200 bg-white p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-xs font-bold text-slate-500">{p.partType ?? "part"}</div>
                    <div className="flex items-center gap-2">
                      <Button variant="secondary" onClick={() => navigator.clipboard.writeText(p.fullId)}>Copy ID</Button>
                      <Button onClick={() => addPart(p)}>Add</Button>
                    </div>
                  </div>
                  <div className="mt-1 text-sm font-black">{p.name}</div>
                  {p.spawnCode && <div className="mt-1 font-mono text-xs break-all text-slate-700">{p.spawnCode}</div>}
                  {p.path && <div className="mt-1 text-xs text-slate-500">{p.path}</div>}
                </div>
              ))}
              {partsForSelectedType.length === 0 && <div className="p-3 text-sm text-slate-500">No parts found for this Type ID.</div>}
            </div>
          )}
        </Card>

        <Card className="p-4 space-y-3 md:col-span-1">
          <div className="flex items-end justify-between gap-2">
            <div>
              <div className="text-sm font-black">Selected Parts</div>
              <div className="text-xs text-slate-500">Build a preset you can export or copy.</div>
            </div>
            <Button variant="secondary" onClick={() => setSelectedParts([])} disabled={selectedParts.length === 0}>
              Clear
            </Button>
          </div>

          <div>
            <div className="text-xs font-bold text-slate-500">Preset label</div>
            <Input value={presetLabel} onChange={(e) => setPresetLabel(e.target.value)} placeholder="e.g. Godroll setup" />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={() => { setPreset(selectedParts, presetLabel.trim() || undefined, selectedTypeId); nav("/builder"); toast("Sent preset to Builder."); }} disabled={selectedParts.length === 0}>Send to Builder</Button>
            <Button onClick={copySelectedSpawnCodes} disabled={selectedParts.length === 0}>Copy Spawn Codes</Button>
            <Button variant="secondary" onClick={copySelectedJson} disabled={selectedParts.length === 0}>Copy Preset JSON</Button>
            <Button variant="secondary" onClick={savePresetToFile} disabled={selectedParts.length === 0}>Save Preset</Button>
            <Button variant="secondary" onClick={loadPresetFromFile}>Load Preset</Button>
          </div>

          <div className="max-h-[360px] overflow-auto rounded-lg border border-slate-200">
            {selectedParts.length === 0 && <div className="p-3 text-sm text-slate-500">No parts selected yet.</div>}
            {selectedParts.map((p) => (
              <div key={p.fullId} className="border-b border-slate-200 bg-white p-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs font-bold text-slate-500">{p.partType ?? "part"} • {p.category ?? ""}</div>
                    <div className="mt-1 text-sm font-black">{p.name}</div>
                    <div className="mt-1 font-mono text-[11px] break-all text-slate-600">{p.fullId}</div>
                  </div>
                  <Button variant="secondary" onClick={() => removePart(p.fullId)}>Remove</Button>
                </div>
                {p.spawnCode && <div className="mt-2 font-mono text-xs break-all text-slate-700">{p.spawnCode}</div>}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
