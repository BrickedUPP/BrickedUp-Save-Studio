import React, { useEffect, useMemo, useState } from "react";
import { open, save } from "@tauri-apps/plugin-dialog";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Card } from "../ui/Card";
import { BusyOverlay } from "../ui/BusyOverlay";
import { useToast } from "../ui/Toast";
import { usePresetStore } from "../app/presetStore";
import { Button } from "../ui/Button";
import { Textarea } from "../ui/Textarea";
import { Input } from "../ui/Input";
import { configEngine } from "../app/engine";
import {
  engine,
  saveEngine,
  saveEngine2,
  saveEngine3,
  fileEngine,
  savEngine,
  slotToolsEngine,
  slotPlanEngine,
  type SerialWithLocation,
  type BackpackSlot,
  type EquippedSlot,
  type LostLootEntry,
} from "../app/engine";

export function SaveEditorPage() {
  const [busy, setBusy] = useState(false);
  const [busyLabel, setBusyLabel] = useState<string | undefined>(undefined);
  const toast = useToast();
  const preset = usePresetStore((s) => s.preset);
  const clearPreset = usePresetStore((s) => s.setPreset);
  const [steamId, setSteamId] = useState("");
  const [serialApplyText, setSerialApplyText] = useState("");
  const [decodedApplyText, setDecodedApplyText] = useState("");
  const [serialApplyTarget, setSerialApplyTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [serialApplyStartSlot, setSerialApplyStartSlot] = useState(1);
  const [serialApplyFlags, setSerialApplyFlags] = useState<string>("");
  const [serialApplyStateFlags, setSerialApplyStateFlags] = useState<string>("");
  const [serialSkipOccupied, setSerialSkipOccupied] = useState<boolean>(true);
  const [clearTarget, setClearTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [clearStart, setClearStart] = useState(1);
  const [clearEnd, setClearEnd] = useState(1);
  const [compactTarget, setCompactTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [compactStartFrom, setCompactStartFrom] = useState(1);
  const [compactPreserveOrder, setCompactPreserveOrder] = useState(true);
  const [exportTarget, setExportTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [exportStart, setExportStart] = useState(1);
  const [exportEnd, setExportEnd] = useState(1);
  const [exportJson, setExportJson] = useState("");
  const [importTarget, setImportTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [importStartSlot, setImportStartSlot] = useState(1);
  const [importSkipOccupied, setImportSkipOccupied] = useState(true);
  const [importJsonText, setImportJsonText] = useState("");
  const [macroSrcTarget, setMacroSrcTarget] = useState<"backpack" | "bank" | "vault">("backpack");
  const [macroDstTarget, setMacroDstTarget] = useState<"backpack" | "bank" | "vault">("bank");
  const [macroStart, setMacroStart] = useState(1);
  const [macroEnd, setMacroEnd] = useState(50);
  const [macroClearSource, setMacroClearSource] = useState(false);
  const [macroSkipOccupied, setMacroSkipOccupied] = useState(true);
  const [macroStartSlot, setMacroStartSlot] = useState(1);
  const [macroCompactAfter, setMacroCompactAfter] = useState(true);
  const [macroCompactStartFrom, setMacroCompactStartFrom] = useState(1);
  const [macroCompactPreserveOrder, setMacroCompactPreserveOrder] = useState(true);
  const [macroCompactBoth, setMacroCompactBoth] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();
  const nav = useNavigate();
  const [offlineCodec, setOfflineCodec] = useState(false);
  const [allowRemoteFallback, setAllowRemoteFallback] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const cfg = await configEngine.get();
        setOfflineCodec(cfg.prefer_offline);
        setAllowRemoteFallback(cfg.allow_remote_fallback);
        if (cfg.steam_id) setSteamId(cfg.steam_id);
      } catch {
        // defaults
      }
    })();
  }, []);

// AUTO_OPEN_EFFECT
useEffect(() => {
  (async () => {
    const openPath = searchParams.get("open");
    if (openPath) {
      // clear param to avoid repeated loads on re-render
      setSearchParams((prev) => {
        const p = new URLSearchParams(prev);
        p.delete("open");
        return p;
      });
      if (!steamId.trim()) {
        toast("Enter Steam/Epic ID, then reopen the save again (required to decrypt).", "error");
        return;
      }
      try {
        setBusy(true); setBusyLabel("Decrypting save…");
        const res = await savEngine.decryptSavFileAuto(openPath, steamId.trim(), offlineCodec, allowRemoteFallback);
        setBusy(false);
        setSavPath(res.path);
        await configEngine.addRecentSav(res.path);
        setSavName(res.file_name);
        setInput(res.yaml_text);
        toast("Loaded save from recent files.");
      } catch (e:any) {
        setBusy(false);
        toast(e?.toString?.() ?? "Failed to open save", "error");
      }
    }
  })();
}, [searchParams, setSearchParams, steamId, offlineCodec, allowRemoteFallback]);

  const [filePath, setFilePath] = useState<string | null>(null);      // for YAML/text
  const [savPath, setSavPath] = useState<string | null>(null);        // for .sav
  const [savName, setSavName] = useState<string | null>(null);

  const [input, setInput] = useState("");
  const [serials, setSerials] = useState<string[]>([]);
  const [base85, setBase85] = useState<string[]>([]);
  const [decoded, setDecoded] = useState<string[]>([]);

  const [withLoc, setWithLoc] = useState<SerialWithLocation[]>([]);
  const [withLocCount, setWithLocCount] = useState(0);

  async function openYamlFile() {
    const selected = await open({
      multiple: false,
      filters: [{ name: "Text/YAML", extensions: ["txt", "yml", "yaml"] }],
    });
    if (!selected || Array.isArray(selected)) return;
    const res = await fileEngine.readTextFile(selected);
    setFilePath(res.path);
    await configEngine.addRecentYaml(res.path);
    setInput(res.content);
  }

  async function saveYamlFile() {
    let path = filePath;
    if (!path) {
      const selected = await save({
        filters: [{ name: "Text/YAML", extensions: ["yml", "yaml", "txt"] }],
      });
      if (!selected) return;
      path = selected;
      setFilePath(path);
      await configEngine.addRecentYaml(path);
    }
    await fileEngine.writeTextFile(path, input);
    await configEngine.addRecentYaml(path);
  }

  async function openSavAndDecrypt() {
    const selected = await open({
      multiple: false,
      filters: [{ name: "BL Save", extensions: ["sav"] }],
    });
    if (!selected || Array.isArray(selected)) return;
    if (!steamId.trim()) {
      toast("Enter Steam/Epic ID first.", "error");
      return;
    }
    setBusy(true); setBusyLabel('Decrypting save…');
    let res;
    try {
      res = await savEngine.decryptSavFileAuto(selected, steamId.trim(), offlineCodec, allowRemoteFallback);
    } catch (e:any) {
      setBusy(false);
      toast(e?.toString?.() ?? "Failed to decrypt save", "error");
      return;
    }
    setBusy(false);
    setSavPath(res.path);
    await configEngine.addRecentSav(res.path);
    setSavName(res.file_name);
    setInput(res.yaml_text);
  }

  async function encryptAndSaveSav() {
    if (!steamId.trim()) {
      toast("Enter Steam/Epic ID first.", "error");
      return;
    }
    setBusy(true); setBusyLabel('Encrypting save…');
    let enc;
    try {
      enc = await savEngine.encryptYamlAuto(steamId.trim(), input, offlineCodec, allowRemoteFallback);
    } catch (e:any) {
      setBusy(false);
      toast(e?.toString?.() ?? "Failed to encrypt save", "error");
      return;
    }
    setBusy(false);

    // Save to original path if available, otherwise Save As
    let outPath = savPath;
    if (!outPath) {
      const selected = await save({
        defaultPath: savName ?? "save_modified.sav",
        filters: [{ name: "BL Save", extensions: ["sav"] }],
      });
      if (!selected) return;
      outPath = selected;
      setSavPath(outPath);
      await configEngine.addRecentSav(outPath);
    }
    await savEngine.writeBinaryFile(outPath, enc.sav_bytes);
    await configEngine.addRecentSav(outPath);
    toast("Saved .sav successfully.");
  }

  async function scan() {
    const res = await engine.parseBulkInput(input);
    setSerials(res.serials);
    setBase85(res.base85);
    setDecoded(res.decoded);
  }

  async function extractWithLocation() {
    const res = await saveEngine.extractSerialsWithLocation(input);
    setWithLoc(res.serials);
    setWithLocCount(res.unique_count);
  }

  const byLocation = useMemo(() => {
    const m = new Map<string, SerialWithLocation[]>();
    for (const s of withLoc) {
      const arr = m.get(s.location) ?? [];
      arr.push(s);
      m.set(s.location, arr);
    }
    return m;
  }, [withLoc]);

  const backpackOnly = useMemo(
    () => (byLocation.get("backpack") ?? []).slice().sort((a, b) => (a.slot ?? 9999) - (b.slot ?? 9999)),
    [byLocation]
  );
  const equippedOnly = useMemo(
    () => (byLocation.get("equipped") ?? []).slice().sort((a, b) => (a.slot ?? 9999) - (b.slot ?? 9999)),
    [byLocation]
  );
  const lostLootOnly = useMemo(() => (byLocation.get("lost_loot") ?? []).slice(), [byLocation]);
  const bankOnly = useMemo(
    () => (byLocation.get("bank") ?? []).slice().sort((a, b) => (a.slot ?? 9999) - (b.slot ?? 9999)),
    [byLocation]
  );
  const vaultOnly = useMemo(
    () => (byLocation.get("vault") ?? []).slice().sort((a, b) => (a.slot ?? 9999) - (b.slot ?? 9999)),
    [byLocation]
  );

  function toSlots(list: SerialWithLocation[]): BackpackSlot[] {
    let nextSlot = 0;
    return list.map((s) => ({
      slot: s.slot ?? nextSlot++,
      serial: s.serial,
      state_flags: s.state_flags ?? null,
    }));
  }

  async function rebuildBackpackFromFound() {
    const res = await saveEngine.setBackpackSlots(input, toSlots(backpackOnly));
    setInput((res as any).yaml_text ?? "");
  }

  async function rebuildEquippedFromFound() {
    let nextSlot = 0;
    const slots: EquippedSlot[] = equippedOnly.map((s) => ({
      slot: s.slot ?? nextSlot++,
      serial: s.serial,
      state_flags: s.state_flags ?? null,
    }));
    const res = await saveEngine2.setEquippedSlots(input, slots);
    setInput((res as any).yaml_text ?? "");
  }

  async function rebuildLostLootFromFound() {
    const entries: LostLootEntry[] = lostLootOnly.map((s) => ({
      serial: s.serial,
      in_machine: s.in_machine ?? null,
    }));
    const res = await saveEngine2.setLostLoot(input, entries);
    setInput((res as any).yaml_text ?? "");
  }

  async function rebuildBankFromFound() {
    const res = await saveEngine3.setBankSlots(input, toSlots(bankOnly));
    setInput((res as any).yaml_text ?? "");
  }

  async function rebuildVaultFromFound() {
    const res = await saveEngine3.setVaultSlots(input, toSlots(vaultOnly));
    setInput((res as any).yaml_text ?? "");
  }

  
function parseSerialLines(text: string): string[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
}

async function serializeAndApplyToYaml() {
  const decodedLines = decodedApplyText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (decodedLines.length === 0) {
    toast("Paste one or more decoded lines first.", "error");
    return;
  }
  try {
    setBusy(true); setBusyLabel("Encoding…");
    const res = await engine.bulkSerialize(decodedLines.join("\n"));
    const serials = (res.output_lines ?? []).map((l) => l.trim()).filter((l) => l.length > 0);
    setBusy(false);
    if (serials.length === 0) {
      toast("No serials produced (check input).", "error");
      return;
    }
    setSerialApplyText(serials.join("\n"));
    toast(`Encoded ${serials.length} line(s). Now applying…`);
    await applySerialsToYaml();
  } catch (e:any) {
    setBusy(false);
    toast(e?.toString?.() ?? "Bulk serialize failed", "error");
  }
}

async function moveSlotsMacro() {
  const a = Number(macroStart);
  const b = Number(macroEnd);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < 1) {
    toast("Macro range must be numbers >= 1.", "error");
    return;
  }
  if (macroSrcTarget === macroDstTarget) {
    toast("Source and destination must be different.", "error");
    return;
  }
  try {
    setBusy(true); setBusyLabel("Exporting source slots…");
    const exp = await slotToolsEngine.exportSlotsRange({
      yaml_text: input,
      target: macroSrcTarget,
      start_slot: a,
      end_slot: b,
    });
    if (exp.count === 0) {
      toast("No slots found in that range.", "error");
      setBusy(false);
      return;
    }
    setBusyLabel("Importing into destination…");
    const imp = await slotToolsEngine.importSlots({
      yaml_text: input,
      target: macroDstTarget,
      entries: exp.entries,
      start_slot: macroStartSlot,
      skip_occupied: macroSkipOccupied,
    });
    let newYaml = imp.yaml_text;

    if (macroClearSource) {
      setBusyLabel("Clearing source range…");
      const clr = await slotToolsEngine.clearSlotsRange({
        yaml_text: newYaml,
        target: macroSrcTarget,
        start_slot: a,
        end_slot: b,
      });
      newYaml = clr.yaml_text;
    }

    setInput(newYaml);
    toast(`Moved ${exp.count} slot(s) ${macroSrcTarget} → ${macroDstTarget}.` + (macroClearSource ? " Source cleared." : ""));
  } catch (e:any) {
    toast(e?.toString?.() ?? "Move macro failed", "error");
  } finally {
    setBusy(false);
  }
}

async function importSlotsFromJson() {
  let obj: any;
  try {
    obj = JSON.parse(importJsonText);
  } catch (e:any) {
    toast("Import JSON is not valid JSON.", "error");
    return;
  }
  const entries = obj?.entries;
  if (!Array.isArray(entries)) {
    toast("Import JSON missing entries[].", "error");
    return;
  }
  const cleaned = entries
    .map((e: any) => ({ slot: Number(e.slot), value: String(e.value ?? "") }))
    .filter((e: any) => Number.isFinite(e.slot) && e.slot > 0 && e.value.length > 0);

  if (cleaned.length === 0) {
    toast("No valid entries to import.", "error");
    return;
  }

  try {
    setBusy(true); setBusyLabel("Importing slots…");
    const res = await slotToolsEngine.importSlots({
      yaml_text: input,
      target: importTarget,
      entries: cleaned,
      start_slot: importStartSlot,
      skip_occupied: importSkipOccupied,
    });
    setInput(res.yaml_text);
    toast(`Imported ${res.placed} slot(s) into ${importTarget} (first slot ${res.first_slot}).`);
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to import slots", "error");
  } finally {
    setBusy(false);
  }
}

async function exportSlotsRange() {
  const a = Number(exportStart);
  const b = Number(exportEnd);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < 1) {
    toast("Export range slots must be numbers >= 1.", "error");
    return;
  }
  try {
    setBusy(true); setBusyLabel("Exporting slots…");
    const res = await slotToolsEngine.exportSlotsRange({
      yaml_text: input,
      target: exportTarget,
      start_slot: a,
      end_slot: b,
    });
    const payload = {
      version: 1,
      exportedAt: new Date().toISOString(),
      target: res.target,
      entries: res.entries,
    };
    const j = JSON.stringify(payload, null, 2);
    setExportJson(j);
    toast(`Exported ${res.count} slot(s).`);
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to export slots", "error");
  } finally {
    setBusy(false);
  }
}

async function compactSlots() {
  const start = Number(compactStartFrom);
  if (!Number.isFinite(start) || start < 1) {
    toast("Compact start slot must be a number >= 1.", "error");
    return;
  }
  try {
    setBusy(true); setBusyLabel("Optimizing inventory…");
    const res = await slotToolsEngine.compactSlots({
      yaml_text: input,
      target: compactTarget,
      start_from: start,
      preserve_order: compactPreserveOrder,
    });
    setInput(res.yaml_text);
    toast(`Optimized ${compactTarget}: ${res.new_count} item(s), moved ${res.moved}.`);
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to compact slots", "error");
  } finally {
    setBusy(false);
  }
}

async function clearSlotsRange() {
  const a = Number(clearStart);
  const b = Number(clearEnd);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < 1) {
    toast("Clear Slots slots must be numbers >= 1.", "error");
    return;
  }
  try {
    setBusy(true); setBusyLabel("Clearing slots…");
    const res = await slotToolsEngine.clearSlotsRange({
      yaml_text: input,
      target: clearTarget,
      start_slot: a,
      end_slot: b,
    });
    setInput(res.yaml_text);
    toast(`Cleared ${res.removed} slot(s) from ${clearTarget}.`);
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to clear slots", "error");
  } finally {
    setBusy(false);
  }
}

async function autoPlanSlots() {
  const serials = parseSerialLines(serialApplyText);
  const count = serials.length > 0 ? serials.length : 1;
  try {
    setBusy(true); setBusyLabel("Planning free slots…");
    const res = await slotPlanEngine.planFreeSlots({
      yaml_text: input,
      target: serialApplyTarget,
      count,
      start_from: 1,
      max_scan: 5000,
    });
    setSerialApplyStartSlot(res.first_slot);
    toast(`Suggested start slot: ${res.first_slot} (found ${res.slots.length} free).`);
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to plan slots", "error");
  } finally {
    setBusy(false);
  }
}

async function applySerialsToYaml() {
  const serials = parseSerialLines(serialApplyText);
  if (serials.length === 0) {
    toast("Paste one or more serial codes first.", "error");
    return;
  }
  const start = Number(serialApplyStartSlot);
  if (!Number.isFinite(start) || start < 1) {
    toast("Start slot must be a number >= 1.", "error");
    return;
  }

  const flags = serialApplyFlags.trim() ? Number(serialApplyFlags.trim()) : undefined;
  const stateFlags = serialApplyStateFlags.trim() ? Number(serialApplyStateFlags.trim()) : undefined;
  if (serialApplyFlags.trim() && !Number.isFinite(flags!)) {
    toast("Flags must be a number.", "error");
    return;
  }
  if (serialApplyStateFlags.trim() && !Number.isFinite(stateFlags!)) {
    toast("State flags must be a number.", "error");
    return;
  }

  let targetSlots: number[] | null = null;
if (serialSkipOccupied) {
  try {
    const plan = await slotPlanEngine.planFreeSlots({
      yaml_text: input,
      target: serialApplyTarget,
      count: serials.length,
      start_from: start,
      max_scan: 5000,
    });
    targetSlots = plan.slots;
  } catch (e:any) {
    toast(e?.toString?.() ?? "Failed to plan free slots", "error");
    return;
  }
}

const slots = serials.map((serial, idx) => ({
  slot: targetSlots ? targetSlots[idx] : start + idx,
  serial,
  flags: flags ?? null,
  state_flags: stateFlags ?? null,
}));

  try {
    setBusy(true); setBusyLabel("Applying serials to YAML…");
    let res: { yaml_text: string };
    if (serialApplyTarget === "backpack") {
      res = await saveEngine.setBackpackSlots(input, slots as any);
    } else if (serialApplyTarget === "bank") {
      res = await saveEngine3.setBankSlots(input, slots as any);
    } else {
      res = await saveEngine3.setVaultSlots(input, slots as any);
    }
    setInput(res.yaml_text);
    toast(`Applied ${serials.length} serial(s) to ${serialApplyTarget}.`);
  } catch (e: any) {
    toast(e?.toString?.() ?? "Failed to apply serials", "error");
  } finally {
    setBusy(false);
  }
}


return (
    <>
      <BusyOverlay show={busy} label={busyLabel} />
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-black">💾 Inventory Manager</div>
          <div className="mt-1 text-sm text-slate-600">
            Now supports: Open .sav → decrypt → edit YAML → encrypt → write .sav (via legacy API).
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={openSavAndDecrypt}>🔓 Open .sav</Button>
          <Button onClick={encryptAndSaveSav}>🔒 Save .sav</Button>
        </div>
      </div>

      <Card className="p-4 space-y-3">
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-xs font-bold text-slate-500">Steam/Epic ID (required for decrypt/encrypt)</div>
            <label className="mt-2 flex items-center gap-2 text-xs text-slate-600">
              <input type="checkbox" checked={offlineCodec} onChange={(e) => setOfflineCodec(e.target.checked)} />
              Prefer offline codec (uses remote fallback unless disabled in Settings)
            </label>
            <Input value={steamId} onChange={(e) => setSteamId(e.target.value)} onBlur={() => configEngine.setSteamId(steamId.trim() ? steamId.trim() : null)} placeholder="e.g. 7656119..." />
          </div>
          <div className="text-xs text-slate-500">
            <div className="font-bold">Loaded</div>
            <div>YAML file: <span className="font-mono">{filePath ?? "(none)"}</span></div>
            <div>.sav file: <span className="font-mono">{savPath ?? "(none)"}{savName ? ` (${savName})` : ""}</span></div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={openYamlFile}>📄 Open YAML</Button>
          <Button variant="secondary" onClick={saveYamlFile}>💾 Save YAML</Button>
          <Button variant="secondary" onClick={() => { setInput(""); setSavPath(null); setSavName(null); setFilePath(null); }}>Clear</Button>
	        </div>
          <div className="mt-3 border-t border-slate-200 pt-3 space-y-2">
  <div className="flex items-end justify-between gap-2">
    <div>
      <div className="text-sm font-black">📤 Export Inventory Range</div>
      <div className="text-xs text-slate-500">Export slot_* values to JSON (for sharing/backup/import).</div>
    </div>
    <div className="flex gap-2">
      <Button variant="secondary" onClick={exportSlotsRange}>Export</Button>
      <Button
        variant="secondary"
        onClick={() => {
          if (!exportJson) return toast("Nothing exported yet.", "error");
          navigator.clipboard.writeText(exportJson);
          toast("Copied export JSON.");
        }}
      >
        Copy JSON
      </Button>
      <Button
        variant="secondary"
        onClick={async () => {
          if (!exportJson) return toast("Nothing exported yet.", "error");
          const p = await save({ defaultPath: `slot_export_${exportTarget}_${exportStart}-${exportEnd}.json`, filters: [{ name: "JSON", extensions: ["json"] }] });
          if (!p) return;
          await fileEngine.writeTextFile(p, exportJson);
          toast("Saved export file.");
        }}
      >
        Save JSON
      </Button>
    </div>
  </div>

  <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2">
  <div className="flex items-end justify-between gap-2">
    <div>
      <div className="text-sm font-black">🚚 Transfer Inventory</div>
      <div className="text-xs text-slate-500">Export from one section, import into another, optionally clear the source.</div>
    </div>
    <Button onClick={moveSlotsMacro}>Execute Transfer</Button>
  </div>

  <div className="grid gap-3 md:grid-cols-6">
    <div className="md:col-span-2">
      <div className="text-xs font-bold text-slate-500">Source</div>
      <select
        value={macroSrcTarget}
        onChange={(e) => setMacroSrcTarget(e.target.value as any)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
      >
        <option value="backpack">Backpack</option>
        <option value="bank">Bank</option>
        <option value="vault">Vault</option>
      </select>
    </div>
    <div className="md:col-span-2">
      <div className="text-xs font-bold text-slate-500">Destination</div>
      <select
        value={macroDstTarget}
        onChange={(e) => setMacroDstTarget(e.target.value as any)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
      >
        <option value="bank">Bank</option>
        <option value="vault">Vault</option>
        <option value="backpack">Backpack</option>
      </select>
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">Start slot</div>
      <Input value={String(macroStart)} onChange={(e) => setMacroStart(Number(e.target.value))} />
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">End slot</div>
      <Input value={String(macroEnd)} onChange={(e) => setMacroEnd(Number(e.target.value))} />
    </div>
  </div>

  <div className="grid gap-3 md:grid-cols-6">
    <div className="md:col-span-2">
      <div className="text-xs font-bold text-slate-500">Destination start slot</div>
      <Input value={String(macroStartSlot)} onChange={(e) => setMacroStartSlot(Number(e.target.value))} />
    </div>
    <div className="md:col-span-2 flex items-end">
      <label className="flex items-center gap-2 text-sm text-slate-700">
        <input type="checkbox" checked={macroSkipOccupied} onChange={(e) => setMacroSkipOccupied(e.target.checked)} />
        Skip occupied (destination)
      </label>
    </div>
    <div className="md:col-span-2 flex items-end">
      <label className="flex items-center gap-2 text-sm text-slate-700">
        <input type="checkbox" checked={macroClearSource} onChange={(e) => setMacroClearSource(e.target.checked)} />
        Clear source range after import
      </label>
    </div>
  </div>
</div>

<div className="grid gap-3 md:grid-cols-4">
    <div>
      <div className="text-xs font-bold text-slate-500">Target</div>
      <select
        value={exportTarget}
        onChange={(e) => setExportTarget(e.target.value as any)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
      >
        <option value="backpack">Backpack</option>
        <option value="bank">Bank</option>
        <option value="vault">Vault</option>
      </select>
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">Start slot</div>
      <Input value={String(exportStart)} onChange={(e) => setExportStart(Number(e.target.value))} />
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">End slot</div>
      <Input value={String(exportEnd)} onChange={(e) => setExportEnd(Number(e.target.value))} />
    </div>
    <div className="text-xs text-slate-500">
      Exports any slot_* lines in the range, sorted by slot.
    </div>
  </div>

  {exportJson && (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
      <div className="text-xs font-bold text-slate-500">Preview</div>
      <div className="mt-1 max-h-[160px] overflow-auto font-mono text-xs whitespace-pre">{exportJson}</div>
    </div>
  )}
</div>

<div className="mt-3 border-t border-slate-200 pt-3 space-y-2">
    <div className="flex items-end justify-between gap-2">
      <div>
        <div className="text-sm font-black">🧳 Optimize Inventory</div>
        <div className="text-xs text-slate-500">Remove gaps and reassign slot numbers starting at a chosen slot.</div>
      </div>
      <Button variant="secondary" onClick={compactSlots}>Compact</Button>
    </div>

    <div className="grid gap-3 md:grid-cols-4">
      <div>
        <div className="text-xs font-bold text-slate-500">Target</div>
        <select
          value={compactTarget}
          onChange={(e) => setCompactTarget(e.target.value as any)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
        >
          <option value="backpack">Backpack</option>
          <option value="bank">Bank</option>
          <option value="vault">Vault</option>
        </select>
      </div>
      <div>
        <div className="text-xs font-bold text-slate-500">Start slot</div>
        <Input value={String(compactStartFrom)} onChange={(e) => setCompactStartFrom(Number(e.target.value))} />
      </div>
      <div className="flex items-end">
        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input type="checkbox" checked={compactPreserveOrder} onChange={(e) => setCompactPreserveOrder(e.target.checked)} />
          Preserve order
        </label>
      </div>
      <div className="text-xs text-slate-500">
        Rewrites slot_* lines. Best for cleaning gaps after deletes.
      </div>
    </div>
  </div>
</Card>

      <Card className="p-4 space-y-3">
        <div className="text-xs font-bold text-slate-500">YAML / text</div>
        <Textarea
          rows={12}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste YAML or decrypt a .sav file..."
        />

        <div className="flex flex-wrap gap-2">
          <Button onClick={scan}>🔎 Extract Serials</Button>
          <Button variant="secondary" onClick={extractWithLocation}>🧭 Extract With Location</Button>
        </div>

        <div className="grid gap-3 md:grid-cols-3 text-sm text-slate-700">
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="text-xs font-bold text-slate-500">Total</div>
            <div className="text-2xl font-black">{serials.length}</div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="text-xs font-bold text-slate-500">Base85 (@Ug...)</div>
            <div className="text-2xl font-black">{base85.length}</div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="text-xs font-bold text-slate-500">Decoded</div>
            <div className="text-2xl font-black">{decoded.length}</div>
          </div>
        </div>
      </Card>

      
{preset && (
  <Card className="p-4 space-y-3">
    <div className="flex items-end justify-between gap-2">
      <div>
        <div className="text-sm font-black">🧩 Preset from Parts Browser</div>
        <div className="text-xs text-slate-500">{preset.label ?? "(no label)"} • {preset.parts.length} parts</div>
        <div className="text-xs text-slate-500">For now this is a parts/spawn-code preset (not item serials). You can paste/export spawn codes while we finalize full item build → serial workflow.</div>
      </div>
      <div className="flex gap-2">
        <Button
          variant="secondary"
          onClick={() => {
            const lines = preset.parts.map((p) => p.spawnCode).filter((x): x is string => !!x && x.trim().length > 0);
            navigator.clipboard.writeText(lines.join("\n"));
            toast("Copied preset spawn codes.");
          }}
        >
          Copy Spawn Codes
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            const lines = preset.parts.map((p) => p.spawnCode).filter((x): x is string => !!x && x.trim().length > 0);
            setInput((cur) => (cur ? cur + "\n" : "") + lines.join("\n"));
            toast("Appended spawn codes into editor.");
          }}
        >
          Append to Editor
        </Button>
        <Button variant="secondary" onClick={() => { clearPreset(null); toast("Cleared preset."); }}>
          Clear
        </Button>
      </div>
    </div>

    <div className="max-h-[240px] overflow-auto rounded-lg border border-slate-200">
      {preset.parts.map((p) => (
        <div key={p.fullId} className="border-b border-slate-200 bg-white p-3">
          <div className="text-xs font-bold text-slate-500">{p.partType ?? "part"} • {p.category ?? ""}</div>
          <div className="mt-1 text-sm font-black">{p.name}</div>
          <div className="mt-1 font-mono text-[11px] break-all text-slate-600">{p.fullId}</div>
          {p.spawnCode && <div className="mt-2 font-mono text-xs break-all text-slate-700">{p.spawnCode}</div>}
        </div>
      ))}
    </div>
  </Card>
)}


<Card className="p-4 space-y-3">
  <div className="flex items-end justify-between gap-2">
    <div>
      <Card className="p-4 space-y-3">
  <div className="flex items-end justify-between gap-2">
    <div>
      <div className="text-sm font-black">⚡ Encode Item Code → Apply</div>
      <div className="text-xs text-slate-500">
        Paste item code lines (one per line). The app will bulk-serialize them into Base85 serials, then apply into YAML using the settings below.
      </div>
    </div>
    <Button onClick={serializeAndApplyToYaml}>Encode & Apply</Button>
  </div>
  <div>
    <div className="text-xs font-bold text-slate-500">Decoded lines (one per line)</div>
    <Textarea value={decodedApplyText} onChange={(e) => setDecodedApplyText(e.target.value)} rows={6} placeholder="(decoded item strings here)"/>
  </div>
</Card>

<div className="text-sm font-black">🧷 Apply Items to Inventory</div>
      <div className="text-xs text-slate-500">
        Paste encoded items (one per line). This writes slots into your YAML (Backpack/Bank/Vault).
      </div>
    </div>
    <div className="flex gap-2"><Button variant="secondary" onClick={autoPlanSlots}>Auto-Assign Slots</Button><Button onClick={applySerialsToYaml}>Apply</Button></div>
  </div>

  <div className="grid gap-3 md:grid-cols-4">
    <div>
      <div className="text-xs font-bold text-slate-500">Target</div>
      <select
        value={serialApplyTarget}
        onChange={(e) => setSerialApplyTarget(e.target.value as any)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
      >
        <option value="backpack">Backpack</option>
        <option value="bank">Bank</option>
        <option value="vault">Vault</option>
      </select>
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">Start slot</div>
      <Input value={String(serialApplyStartSlot)} onChange={(e) => setSerialApplyStartSlot(Number(e.target.value))} />
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">Flags (optional)</div>
      <Input value={serialApplyFlags} onChange={(e) => setSerialApplyFlags(e.target.value)} placeholder="e.g. 0" />
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">State flags (optional)</div>
      <Input value={serialApplyStateFlags} onChange={(e) => setSerialApplyStateFlags(e.target.value)} placeholder="e.g. 0" />
    </div>
  </div>

  <div>
    <div className="text-xs font-bold text-slate-500">Items (one per line)</div>
    <Textarea value={serialApplyText} onChange={(e) => setSerialApplyText(e.target.value)} rows={6} placeholder="@UgAAAA..." />
  </div>
</Card>


<Card className="p-4 space-y-3">
  <div className="flex items-end justify-between gap-2">
    <div>
      <div className="text-sm font-black">🧹 Vault Tools</div>
      <div className="text-xs text-slate-500">
        Maintenance helpers for Backpack/Bank/Vault slots.
      </div>
    </div>
    <Button variant="secondary" onClick={clearSlotsRange}>Clear Slots</Button>
  </div>

  <div className="grid gap-3 md:grid-cols-4">
    <div>
      <div className="text-xs font-bold text-slate-500">Target</div>
      <select
        value={clearTarget}
        onChange={(e) => setClearTarget(e.target.value as any)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
      >
        <option value="backpack">Backpack</option>
        <option value="bank">Bank</option>
        <option value="vault">Vault</option>
      </select>
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">Start slot</div>
      <Input value={String(clearStart)} onChange={(e) => setClearStart(Number(e.target.value))} />
    </div>
    <div>
      <div className="text-xs font-bold text-slate-500">End slot</div>
      <Input value={String(clearEnd)} onChange={(e) => setClearEnd(Number(e.target.value))} />
    </div>
    <div className="text-xs text-slate-500">
      Clears slot_* lines in the selected section (best-effort, line-based).
    </div>
  </div>
</Card>

<Card className="p-4 space-y-3">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="text-sm font-black">🧭 Location Scan</div>
            <div className="text-xs text-slate-600">
              Unique serials: <b>{withLocCount}</b> • Backpack: <b>{backpackOnly.length}</b> • Equipped: <b>{equippedOnly.length}</b> • Lost Loot: <b>{lostLootOnly.length}</b> • Bank: <b>{bankOnly.length}</b> • Vault: <b>{vaultOnly.length}</b>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={rebuildBackpackFromFound} disabled={backpackOnly.length === 0}>
              🧱 Backpack
            </Button>
            <Button variant="secondary" onClick={rebuildEquippedFromFound} disabled={equippedOnly.length === 0}>
              🧰 Equipped
            </Button>
            <Button variant="secondary" onClick={rebuildLostLootFromFound} disabled={lostLootOnly.length === 0}>
              🎰 Lost Loot
            </Button>
            <Button variant="secondary" onClick={rebuildBankFromFound} disabled={bankOnly.length === 0}>
              🏦 Bank
            </Button>
            <Button variant="secondary" onClick={rebuildVaultFromFound} disabled={vaultOnly.length === 0}>
              🗄️ Vault
            </Button>
          </div>
        </div>

        <div className="overflow-auto rounded-lg border border-slate-200">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="px-3 py-2">Location</th>
                <th className="px-3 py-2">Slot</th>
                <th className="px-3 py-2">State Flags</th>
                <th className="px-3 py-2">In Machine</th>
                <th className="px-3 py-2">Serial</th>
              </tr>
            </thead>
            <tbody>
              {withLoc.slice(0, 300).map((r) => (
                <tr key={r.serial} className="border-t border-slate-200">
                  <td className="px-3 py-2 font-semibold">{r.location}</td>
                  <td className="px-3 py-2">{r.slot ?? ""}</td>
                  <td className="px-3 py-2">{r.state_flags ?? ""}</td>
                  <td className="px-3 py-2">{r.in_machine ?? ""}</td>
                  <td className="px-3 py-2 font-mono">{r.serial}</td>
                </tr>
              ))}
              {withLoc.length > 300 && (
                <tr className="border-t border-slate-200">
                  <td className="px-3 py-2 text-slate-500" colSpan={5}>
                    Showing first 300 rows…
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
	    </div>
	  </>
	  );
}
