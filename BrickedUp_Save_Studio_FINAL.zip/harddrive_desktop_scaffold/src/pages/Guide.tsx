import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { guideEngine, type GuideIndexResponse, type GuideGetResponse } from "../app/engine";
import { useToast } from "../ui/Toast";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export function GuidePage() {
  const toast = useToast();
  const [index, setIndex] = useState<GuideIndexResponse | null>(null);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<string>("start");
  const [page, setPage] = useState<GuideGetResponse | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        await guideEngine.init();
        const idx = await guideEngine.index();
        setIndex(idx);
        setActive(idx.sections?.[0]?.id ?? "start");
      } catch (e: any) {
        toast(e?.toString?.() ?? "Failed to load guide", "error");
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        setBusy(true);
        const p = await guideEngine.get({ id: active });
        setPage(p);
      } catch (e: any) {
        toast(e?.toString?.() ?? "Failed to load guide page", "error");
      } finally {
        setBusy(false);
      }
    })();
  }, [active]);

  const sections = useMemo(() => {
    const all = index?.sections ?? [];
    const q = query.trim().toLowerCase();
    if (!q) return all;
    return all.filter((s) => s.title.toLowerCase().includes(q) || s.id.toLowerCase().includes(q));
  }, [index, query]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card className="p-3">
        <div className="text-sm font-black">📖 Local Guide</div>
        <div className="mt-1 text-xs text-subtle">
          Version {index?.version ?? "—"} • Updated {index?.last_updated ? new Date(index.last_updated).toLocaleString() : "—"}
        </div>

        <div className="mt-3">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search…"
            className="w-full rounded-xl border border-border bg-surface px-3 py-2 text-sm text-fg outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="mt-3 space-y-1">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActive(s.id)}
              className={[
                "w-full text-left rounded-xl px-3 py-2 text-sm",
                active === s.id ? "bg-accent text-accent-fg" : "hover:bg-muted text-fg",
              ].join(" ")}
            >
              {s.title}
            </button>
          ))}
        </div>

        <div className="mt-3 text-xs text-subtle">
          Works offline. Use Settings for update checks.
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-lg font-black">{page?.title ?? "Loading…"}</div>
            <div className="text-xs text-subtle">BrickedUp Save Studio • by BRICKEDNLOADED</div>
          </div>
          <Button variant="secondary" onClick={() => toast("Guide updates will be added next.", "info")}>
            Check Guide Updates
          </Button>
        </div>

        <div className="mt-4 rounded-xl border border-border bg-muted p-4">
          {busy ? (
            <div className="text-sm text-subtle">Loading…</div>
          ) : (
            <ReactMarkdown remarkPlugins={[remarkGfm]} className="prose prose-sm max-w-none">
              {page?.markdown ?? ""}
            </ReactMarkdown>
          )}
        </div>
      </Card>
    </div>
  );
}
