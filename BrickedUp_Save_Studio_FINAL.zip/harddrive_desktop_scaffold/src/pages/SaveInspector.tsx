import React, { useState } from "react";
import { open } from "@tauri-apps/plugin-dialog";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { BusyOverlay } from "../ui/BusyOverlay";
import { useToast } from "../ui/Toast";
import { probeEngine, type SavProbeResponse, configEngine } from "../app/engine";

export function SaveInspectorPage() {
  const [busy, setBusy] = useState(false);
  const [probe, setProbe] = useState<SavProbeResponse | null>(null);
  const toast = useToast();

  async function pickAndProbe() {
    const selected = await open({
      multiple: false,
      filters: [{ name: "BL Save", extensions: ["sav"] }],
    });
    if (!selected || Array.isArray(selected)) return;

    try {
      setBusy(true);
      const res = await probeEngine.savProbeFile(selected);
      setProbe(res);
      await configEngine.addRecentSav(res.path);
      toast("Probed save file.");
    } catch (e: any) {
      toast(e?.toString?.() ?? "Probe failed", "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <BusyOverlay show={busy} label="Probing save…" />
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="text-2xl font-black">🔬 Save Inspector</div>
          <div className="mt-1 text-sm text-slate-600">
            Diagnostics to support the offline save codec (file size, hashes, header magic).
          </div>
        </div>
        <Button onClick={pickAndProbe}>📂 Choose .sav</Button>
      </div>

      <Card className="p-4 space-y-3">
        {!probe && <div className="text-sm text-slate-500">Choose a .sav file to inspect.</div>}
        {probe && (
          <div className="space-y-3 text-sm">
            <div>
              <div className="text-xs font-bold text-slate-500">Path</div>
              <div className="font-mono break-all">{probe.path}</div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-xs font-bold text-slate-500">File size</div>
                <div className="text-xl font-black">{probe.file_size.toLocaleString()} bytes</div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-xs font-bold text-slate-500">Magic</div>
                <div className="text-sm font-semibold">{probe.magic_guess}</div>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-xs font-bold text-slate-500">First 16 bytes (hex)</div>
                <div className="font-mono break-all">{probe.first16_hex}</div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-xs font-bold text-slate-500">First 16 bytes (ascii)</div>
                <div className="font-mono">{probe.first16_ascii}</div>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <div className="text-xs font-bold text-slate-500">SHA-256</div>
              <div className="font-mono break-all">{probe.sha256}</div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
