\
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod engine;

use regex::Regex;
use serde::{Deserialize, Serialize};
use base64::Engine;

#[derive(Debug, Serialize, Deserialize)]
pub struct ParseWeaponCodeResponse {
    pub normalized: Option<String>,
    pub serialized: Option<String>,
    pub breakdown: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ParseBulkInputResponse {
    /// Preserves order found, de-duped.
    pub serials: Vec<String>,
    /// Subset that look like base85 (start with @Ug).
    pub base85: Vec<String>,
    /// Subset that look like decoded form (e.g. 259, 0, 1, 50|...).
    pub decoded: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BrickRollRequest {
    pub seed: u32,
    pub intensity: u32,
    pub base_code: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BrickRollResponse {
    pub deserialized: Option<String>,
    pub serialized: Option<String>,
    pub breakdown: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SerializeRequest {
    pub decoded: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DeserializeRequest {
    pub serial_b85: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DeserializeResponse {
    /// Legacy API returns `serial` (decoded string).
    pub serial: Option<String>,
    /// Some responses return message/err
    pub error: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SerializeResponse {
    /// Legacy API returns `serial_b85`.
    pub serial_b85: Option<String>,
    pub error: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BulkConvertResponse {
    pub output_lines: Vec<String>,
    pub ok: usize,
    pub failed: usize,
}


#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct SerialWithLocation {
    pub serial: String,
    pub index: usize,
    pub location: String,
    pub slot: Option<i32>,
    pub state_flags: Option<i64>,
    pub in_machine: Option<bool>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveExtractResponse {
    pub serials: Vec<SerialWithLocation>,
    pub unique_count: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BackpackSlot {
    pub slot: i32,
    pub serial: String,
    pub flags: Option<i64>,
    pub state_flags: Option<i64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct EquippedSlot {
    pub slot: i32,
    pub serial: String,
    pub state_flags: Option<i64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct LostLootEntry {
    pub serial: String,
    pub in_machine: Option<bool>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveUpdateEquippedRequest {
    pub yaml_text: String,
    pub slots: Vec<EquippedSlot>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveUpdateLostLootRequest {
    pub yaml_text: String,
    pub entries: Vec<LostLootEntry>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BackpackSlot {
    pub slot: i32,
    pub serial: String,
    pub flags: Option<i64>,
    pub state_flags: Option<i64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveUpdateBackpackRequest {
    pub yaml_text: String,
    pub slots: Vec<BackpackSlot>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SavePlanSlotsRequest {
    pub yaml_text: String,
    /// backpack | bank | vault
    pub target: String,
    /// number of slots needed
    pub count: u32,
    /// start scanning from this slot (default 1)
    pub start_from: Option<u32>,
    /// max slot number to scan (default 5000)
    pub max_scan: Option<u32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SavePlanSlotsResponse {
    pub target: String,
    pub slots: Vec<u32>,
    pub first_slot: u32,
    pub scanned_up_to: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveClearSlotsRequest {
    pub yaml_text: String,
    /// backpack | bank | vault
    pub target: String,
    pub start_slot: u32,
    pub end_slot: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveClearSlotsResponse {
    pub yaml_text: String,
    pub removed: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveCompactSlotsRequest {
    pub yaml_text: String,
    /// backpack | bank | vault
    pub target: String,
    /// start slot number to compact into (default 1)
    pub start_from: Option<u32>,
    /// if true, preserves original slot order (ascending), but compacts gaps.
    pub preserve_order: Option<bool>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveCompactSlotsResponse {
    pub yaml_text: String,
    pub moved: u32,
    pub new_count: u32,
    pub start_from: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveExportSlotsRequest {
    pub yaml_text: String,
    pub target: String, // backpack | bank | vault
    pub start_slot: u32,
    pub end_slot: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ExportedSlotEntry {
    pub slot: u32,
    pub value: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveExportSlotsResponse {
    pub target: String,
    pub entries: Vec<ExportedSlotEntry>,
    pub count: u32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveImportSlotsRequest {
    pub yaml_text: String,
    pub target: String, // backpack | bank | vault
    pub entries: Vec<ExportedSlotEntry>,
    /// if provided, ignore entry.slot and start placing sequentially at start_slot
    pub start_slot: Option<u32>,
    /// if true, will skip occupied slots by planning free slots and mapping entries into them
    pub skip_occupied: Option<bool>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveImportSlotsResponse {
    pub yaml_text: String,
    pub placed: u32,
    pub first_slot: u32,
}






#[derive(Debug, Serialize, Deserialize)]
pub struct SaveUpdateBackpackResponse {
    pub yaml_text: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ReadTextFileResponse {
    pub path: String,
    pub content: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct WriteTextFileRequest {
    pub path: String,
    pub content: String,
}

#[derive(Debug, Serialize, Deserialize)]
#[derive(Debug, Serialize, Deserialize)]
#[derive(Debug, Serialize, Deserialize)]
pub struct GameDataUpdateResponse {
    pub updated: bool,
    pub source: String,
    pub sha256: String,
    pub bytes: u64,
    pub cached_path: String,
}

pub struct SavProbeResponse {
    pub path: String,
    pub file_size: u64,
    pub sha256: String,
    pub first16_hex: String,
    pub first16_ascii: String,
    pub magic_guess: String,
}

pub struct SaveDecryptRequest {
    pub path: String,
    pub steamid: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveDecryptResponse {
    pub path: String,
    pub file_name: String,
    pub yaml_text: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveEncryptRequest {
    pub steamid: String,
    pub yaml_text: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveEncryptResponse {
    /// Raw .sav bytes after encryption.
    pub sav_bytes: Vec<u8>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct AppConfig {
    /// Prefer offline codec when possible.
    pub prefer_offline: bool,
    /// Allow using remote API as a fallback when offline codec isn't available.
    pub allow_remote_fallback: bool,
    /// Remember Steam/Epic ID locally (optional).
    pub steam_id: Option<String>,
    /// Reopen the most recently opened .sav on app launch.
    pub reopen_last_on_launch: bool,
    /// Last opened .sav path (if any).
    pub last_opened_sav_path: Option<String>,
    /// Unlock all parts / use full parts catalog.
    pub unlock_all_parts: bool,
    /// Most-recently-used .sav paths (max 10)
    pub recent_sav_paths: Vec<String>,
    /// Unlock all parts / use full parts catalog.
    pub unlock_all_parts: bool,
    /// Most-recently-used yaml paths (max 10)
    pub recent_yaml_paths: Vec<String>,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            prefer_offline: false,
            allow_remote_fallback: true,
            steam_id: None,
            reopen_last_on_launch: false,
            last_opened_sav_path: None,
            recent_sav_paths: Vec::new(),
            recent_yaml_paths: Vec::new(),
            unlock_all_parts: false,
        }
    }
}
const GAME_DATA_URL: &str = "https://borderlands.be/json_proxy.php";
const SAVE_API_URL: &str = "https://borderlands.be/nicnl/api.php";
const LEGACY_API_URL: &str = "https://borderlands.be/nicnl/api.php";

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct GuideSection {
    pub id: String,
    pub title: String,
    pub file: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GuideIndexResponse {
    pub version: String,
    pub last_updated: String,
    pub sections: Vec<GuideSection>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GuideGetRequest {
    pub id: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GuideGetResponse {
    pub id: String,
    pub title: String,
    pub markdown: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GuideInitResponse {
    pub created: bool,
    pub path: String,
}



/// Ensure the local guide bundle exists in the app data directory (offline-first).
#[tauri::command]
pub fn guide_init() -> Result<GuideInitResponse, String> {
    let dir = guide_dir_path()?;
    let idx_path = guide_index_path()?;
    if idx_path.exists() {
        return Ok(GuideInitResponse { created: false, path: dir.to_string_lossy().to_string() });
    }

    // Write index + default pages
    std::fs::write(&idx_path, default_guide_index_json()).map_err(|e| e.to_string())?;

    let index: GuideIndexResponse = serde_json::from_str(&std::fs::read_to_string(&idx_path).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;

    for sec in index.sections.iter() {
        let p = dir.join(&sec.file);
        if !p.exists() {
            std::fs::write(p, default_guide_file(&sec.file)).map_err(|e| e.to_string())?;
        }
    }

    Ok(GuideInitResponse { created: true, path: dir.to_string_lossy().to_string() })
}

/// Load the guide index from local storage.
#[tauri::command]
pub fn guide_index() -> Result<GuideIndexResponse, String> {
    let idx_path = guide_index_path()?;
    if !idx_path.exists() {
        // create defaults if missing
        let _ = guide_init()?;
    }
    let s = std::fs::read_to_string(idx_path).map_err(|e| e.to_string())?;
    let mut index: GuideIndexResponse = serde_json::from_str(&s).map_err(|e| e.to_string())?;
    // If last_updated missing in older caches, set it.
    if index.last_updated.is_empty() {
        index.last_updated = chrono::Utc::now().to_rfc3339();
    }
    Ok(index)
}

/// Load a specific guide page by id.
#[tauri::command]
pub fn guide_get(req: GuideGetRequest) -> Result<GuideGetResponse, String> {
    let index = guide_index()?;
    let sec = index.sections.iter().find(|s| s.id == req.id)
        .ok_or_else(|| "Guide page not found".to_string())?;

    let dir = guide_dir_path()?;
    let p = dir.join(&sec.file);
    if !p.exists() {
        // regenerate defaults if missing
        std::fs::write(&p, default_guide_file(&sec.file)).map_err(|e| e.to_string())?;
    }
    let md = std::fs::read_to_string(p).map_err(|e| e.to_string())?;
    Ok(GuideGetResponse { id: sec.id.clone(), title: sec.title.clone(), markdown: md })
}


#[tauri::command]
pub fn parse_weapon_code(code: String) -> Result<ParseWeaponCodeResponse, String> {
    let normalized = normalize_code(&code);
    Ok(ParseWeaponCodeResponse {
        normalized: Some(normalized),
        serialized: None,
        breakdown: Some("Breakdown will be implemented by the Rust engine.".to_string()),
    })
}

/// Extract serials from pasted text in multiple formats.
/// Mirrors legacy parseBulkInput().
#[tauri::command]
pub fn parse_bulk_input(text: String) -> Result<ParseBulkInputResponse, String> {
    let input = text.trim().to_string();
    if input.is_empty() {
        return Ok(ParseBulkInputResponse {
            serials: vec![],
            base85: vec![],
            decoded: vec![],
        });
    }

    let mut found: Vec<String> = vec![];

    // 1) JS object format: code: '...' or code: "..." or code: `...`
    let code_re = Regex::new(r#"code:\s*['"`]([^'"`]+)['"`]"#).map_err(|e| e.to_string())?;
    for cap in code_re.captures_iter(&input) {
        if let Some(m) = cap.get(1) {
            let code = m.as_str().trim().to_string();
            if looks_like_serial(&code) {
                found.push(code);
            }
        }
    }

    // 2) YAML format: serial: '@Ug...'
    if found.is_empty() {
        let yaml_re =
            Regex::new(r#"serial:\s*['"]?(@Ug[^\s\n'"]+)['"]?"#).map_err(|e| e.to_string())?;
        for cap in yaml_re.captures_iter(&input) {
            if let Some(m) = cap.get(1) {
                let mut serial = m.as_str().trim().to_string();
                serial = serial.trim_matches(&['"', '\''][..]).to_string();
                if is_valid_base85(&serial) {
                    found.push(serial);
                }
            }
        }
    }

    // 3) Line-by-line fallback
    if found.is_empty() {
        for line in input.lines() {
            let t = line.trim();
            if t.is_empty() || t.starts_with('#') || t.starts_with("//") {
                continue;
            }

            if let Some(idx) = t.find("@Ug") {
                let tail = &t[idx..];
                let token = tail
                    .split_whitespace()
                    .next()
                    .unwrap_or("")
                    .trim_matches(&['"', '\'', ',', ';'][..])
                    .to_string();
                if is_valid_base85(&token) {
                    found.push(token);
                    continue;
                }
            }

            if is_decoded_serial(t) {
                found.push(t.to_string());
            }
        }
    }

    // De-dupe preserving order
    let mut seen = std::collections::HashSet::new();
    found.retain(|s| seen.insert(s.clone()));

    let mut base85 = Vec::new();
    let mut decoded = Vec::new();
    for s in &found {
        if s.starts_with("@Ug") {
            base85.push(s.clone());
        } else if is_decoded_serial(s) {
            decoded.push(s.clone());
        }
    }

    Ok(ParseBulkInputResponse {
        serials: found,
        base85,
        decoded,
    })
}

#[tauri::command]
pub fn ensure_trailing_pipe(s: String) -> Result<String, String> {
    Ok(if s.trim_end().ends_with('|') {
        s
    } else {
        format!("{}|", s.trim_end())
    })
}

#[tauri::command]
pub fn normalize_bulk_input(text: String) -> Result<Vec<String>, String> {
    Ok(text
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .map(|l| l.to_string())
        .collect())
}


/// Read a UTF-8 text file from disk. (Used for YAML view/edit in Save Editor)
#[tauri::command]
pub fn read_text_file(path: String) -> Result<ReadTextFileResponse, String> {
    let content = std::fs::read_to_string(&path).map_err(|e| e.to_string())?;
    Ok(ReadTextFileResponse { path, content })
}

/// Write a UTF-8 text file to disk.
#[tauri::command]
pub fn write_text_file(req: WriteTextFileRequest) -> Result<(), String> {
    std::fs::write(&req.path, req.content).map_err(|e| e.to_string())?;
    Ok(())
}


fn config_path() -> Result<std::path::PathBuf, String> {
    let proj = directories::ProjectDirs::from("com", "BrickedUp", "HardDriveDesktop")
        .ok_or_else(|| "Failed to resolve app config directory".to_string())?;
    let dir = proj.config_dir();
    std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    Ok(dir.join("config.json"))
}

        fn guide_dir_path() -> Result<std::path::PathBuf, String> {
            let proj = directories::ProjectDirs::from("com", "BrickedUp", "HardDriveDesktop")
                .ok_or_else(|| "Failed to resolve app data directory".to_string())?;
            let dir = proj.data_local_dir().join("guides");
            std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
            Ok(dir)
        }

        fn guide_index_path() -> Result<std::path::PathBuf, String> {
            Ok(guide_dir_path()?.join("index.json"))
        }

        fn default_guide_index_json() -> String {
            // Keep this tiny and stable; content can be expanded later.
            let now = chrono::Utc::now().to_rfc3339();
            let obj = serde_json::json!({
                "version": "1.0.0",
                "last_updated": now,
                "sections": [
                    { "id": "start", "title": "Getting Started", "file": "getting_started.md" },
                    { "id": "inventory", "title": "Inventory Manager", "file": "inventory_manager.md" },
                    { "id": "builder", "title": "BrickedUp Builder", "file": "brickedup_builder.md" },
                    { "id": "vault", "title": "Vault Tools", "file": "vault_tools.md" },
                    { "id": "updates", "title": "Updates & Offline", "file": "updates_offline.md" }
                ]
            });
            obj.to_string()
        }

        fn default_guide_file(name: &str) -> String {
            match name {
                "getting_started.md" => r#"# Getting Started

Welcome to **BrickedUp Save Studio** — built tough for real saves.

## First run
1. Open **Settings → Resources** and download game data (recommended).
2. Open a `.sav` file in **Inventory Manager**.
3. Decrypt → edit → encrypt back.

## Safety
- Always keep a backup of your saves.
- The app can create backups automatically (recommended).
"#.to_string(),

                "inventory_manager.md" => r#"# Inventory Manager

This is where you open a `.sav`, decrypt it to YAML, edit it, and encrypt it back.

## Typical workflow
1. **Open Save**
2. **Decrypt**
3. Use **Apply Items** or **Vault Tools**
4. **Encrypt** and save

## Tips
- Use **Protect existing items** when applying to avoid overwriting.
- Use **Optimize Inventory** after deletes to remove gaps.
"#.to_string(),

                "brickedup_builder.md" => r#"# BrickedUp Builder

Forge item codes and send them to the Inventory Manager.

## Workflow
1. Pick a base item + parts (via Parts Library).
2. **Forge Item Code**
3. Copy → go to Inventory Manager → **Encode & Apply**
"#.to_string(),

                "vault_tools.md" => r#"# Vault Tools

Power tools for managing Backpack / Bank / Vault safely.

## Tools
- **Clear Slots**: remove items in a range.
- **Optimize Inventory**: removes gaps by compacting slot numbers.
- **Export / Import Inventory Range**: share or transfer items via JSON.
- **Transfer Inventory**: move between sections with protections.
"#.to_string(),

                "updates_offline.md" => r#"# Updates & Offline

## Game data updates
- The app can check for updates and refresh parts data.
- Recommended: check for updates on startup (fast check), download on demand.

## Offline mode
- Save editing is designed to work offline.
- Parts data uses local cache after downloading once.
"#.to_string(),

                _ => "# Guide

Missing page.
".to_string()
            }
        }

fn game_data_cache_path() -> Result<std::path::PathBuf, String> {
    let proj = directories::ProjectDirs::from("com", "BrickedUp", "HardDriveDesktop")
        .ok_or_else(|| "Failed to resolve app data directory".to_string())?;
    let dir = proj.data_local_dir();
    std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    Ok(dir.join("game_data_export.json"))
}

fn sha256_hex(bytes: &[u8]) -> String {
    use sha2::Digest;
    let mut hasher = sha2::Sha256::new();
    hasher.update(bytes);
    hex::encode(hasher.finalize())
}


fn load_config() -> Result<AppConfig, String> {
    let path = config_path()?;
    if !path.exists() {
        return Ok(AppConfig::default());
    }
    let txt = std::fs::read_to_string(&path).map_err(|e| e.to_string())?;
    serde_json::from_str(&txt).map_err(|e| e.to_string())
}

fn save_config(cfg: &AppConfig) -> Result<(), String> {
    let path = config_path()?;
    let txt = serde_json::to_string_pretty(cfg).map_err(|e| e.to_string())?;
    std::fs::write(path, txt).map_err(|e| e.to_string())?;
    Ok(())
}


fn push_recent(list: &mut Vec<String>, path: &str, max: usize) {
    let p = path.to_string();
    list.retain(|x| x != &p);
    list.insert(0, p);
    if list.len() > max {
        list.truncate(max);
    }
}

#[tauri::command]
pub fn add_recent_sav(path: String) -> Result<AppConfig, String> {
    let mut cfg = load_config().unwrap_or_default();
    push_recent(&mut cfg.recent_sav_paths, &path, 10);
    cfg.last_opened_sav_path = Some(path.clone());
    save_config(&cfg)?;
    Ok(cfg)
}

#[tauri::command]
pub fn add_recent_yaml(path: String) -> Result<AppConfig, String> {
    let mut cfg = load_config().unwrap_or_default();
    push_recent(&mut cfg.recent_yaml_paths, &path, 10);
    save_config(&cfg)?;
    Ok(cfg)
}

#[tauri::command]
pub fn get_app_config() -> Result<AppConfig, String> {
    load_config()
}

#[tauri::command]
pub fn set_app_config(cfg: AppConfig) -> Result<(), String> {
    save_config(&cfg)
}

/// Downloads the latest game data from the remote API and caches it locally.
/// Returns whether the cached file changed (sha256 changed).
#[tauri::command]
pub async fn game_data_update_on_start() -> Result<GameDataUpdateResponse, String> {
    let cache_path = game_data_cache_path()?;

    let existing = std::fs::read(&cache_path).ok();
    let existing_hash = existing.as_ref().map(|b| sha256_hex(b));

    let client = reqwest::Client::new();
    let res = client.get(GAME_DATA_URL).send().await.map_err(|e| e.to_string())?;
    let status = res.status();
    if !status.is_success() {
        return Err(format!("Game data fetch failed: HTTP {status}"));
    }
    let bytes = res.bytes().await.map_err(|e| e.to_string())?.to_vec();
    let new_hash = sha256_hex(&bytes);

    let updated = match existing_hash {
        Some(h) if h == new_hash => false,
        _ => {
            std::fs::write(&cache_path, &bytes).map_err(|e| e.to_string())?;
            true
        }
    };

    Ok(GameDataUpdateResponse {
        updated,
        source: GAME_DATA_URL.to_string(),
        sha256: new_hash,
        bytes: bytes.len() as u64,
        cached_path: cache_path.to_string_lossy().to_string(),
    })
}

/// Loads cached game data JSON text (if present).
#[tauri::command]
pub fn game_data_load_cached() -> Result<String, String> {
    let cache_path = game_data_cache_path()?;
    std::fs::read_to_string(&cache_path).map_err(|e| e.to_string())
}


#[tauri::command]
pub fn set_steam_id(steamId: Option<String>) -> Result<AppConfig, String> {
    let mut cfg = load_config().unwrap_or_default();
    cfg.steam_id = steamId;
    save_config(&cfg)?;
    Ok(cfg)
}


/// Read a binary file from disk.
#[tauri::command]
pub fn read_binary_file(path: String) -> Result<Vec<u8>, String> {
    std::fs::read(&path).map_err(|e| e.to_string())
}

/// Quick diagnostics for a .sav file to support offline codec development.
#[tauri::command]

/// Suggest free slot numbers for a section by scanning existing slot_* keys.
/// This is best-effort: it parses YAML text line-based (same philosophy as the section rewriters).
#[tauri::command]

/// Remove slot_* entries in a given inclusive range for backpack/bank/vault.
#[tauri::command]

/// Compact slot_* entries by removing gaps and reassigning slot numbers starting from start_from.
/// This is best-effort line-based and assumes one-line slot entries (slot_#: <value>).
#[tauri::command]

/// Export slot_* entries in an inclusive range for backpack/bank/vault.
/// Returns the raw YAML values after the colon (usually Base85 serial strings, or nested YAML if present).
#[tauri::command]

/// Import exported slot entries into backpack/bank/vault.
/// Writes/overwrites slot_* lines for the computed destination slots.
#[tauri::command]
pub fn save_import_slots(req: SaveImportSlotsRequest) -> Result<SaveImportSlotsResponse, String> {
    let target = req.target.to_lowercase();
    if target != "backpack" && target != "bank" && target != "vault" {
        return Err("target must be backpack|bank|vault".to_string());
    }
    if req.entries.is_empty() {
        return Err("No entries to import".to_string());
    }

    // Determine destination slots:
    let base_start = req.start_slot.unwrap_or(1).max(1);

    // If skip_occupied, plan free slots using existing planner
    let mut dest_slots: Vec<u32> = Vec::new();
    if req.skip_occupied.unwrap_or(true) {
        let plan = save_plan_free_slots(SavePlanSlotsRequest {
            yaml_text: req.yaml_text.clone(),
            target: target.clone(),
            count: req.entries.len() as u32,
            start_from: Some(base_start),
            max_scan: Some(5000),
        })?;
        dest_slots = plan.slots;
        if dest_slots.len() != req.entries.len() {
            return Err("Not enough free slots found to place entries".to_string());
        }
    } else {
        dest_slots = (0..req.entries.len()).map(|i| base_start + i as u32).collect();
    }

    // Build SlotUpdate list to reuse existing setters
    let mut updates: Vec<SlotUpdate> = Vec::new();
    for (i, entry) in req.entries.iter().enumerate() {
        updates.push(SlotUpdate {
            slot: dest_slots[i] as i32,
            serial: entry.value.clone(),
            flags: None,
            state_flags: None,
        });
    }

    let yaml_text = req.yaml_text.clone();
    let res_yaml = if target == "backpack" {
        save_set_backpack_slots(SaveUpdateBackpackRequest { yaml_text, slots: updates })?.yaml_text
    } else if target == "bank" {
        save_set_bank_slots(SaveUpdateBankRequest { yaml_text, slots: updates })?.yaml_text
    } else {
        save_set_vault_slots(SaveUpdateVaultRequest { yaml_text, slots: updates })?.yaml_text
    };

    Ok(SaveImportSlotsResponse { yaml_text: res_yaml, placed: req.entries.len() as u32, first_slot: dest_slots[0] })
}


pub fn save_export_slots_range(req: SaveExportSlotsRequest) -> Result<SaveExportSlotsResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let target = req.target.to_lowercase();
    if target != "backpack" && target != "bank" && target != "vault" {
        return Err("target must be backpack|bank|vault".to_string());
    }
    if req.start_slot == 0 || req.end_slot == 0 {
        return Err("slot numbers must be >= 1".to_string());
    }
    let (a, b) = if req.start_slot <= req.end_slot { (req.start_slot, req.end_slot) } else { (req.end_slot, req.start_slot) };

    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();
    let section_header = format!("{target}:");

    let mut start_idx: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == section_header {
            start_idx = i as isize;
            break;
        }
    }
    if start_idx < 0 {
        return Ok(SaveExportSlotsResponse { target, entries: vec![], count: 0 });
    }

    let header_indent_len = lines[start_idx as usize].chars().take_while(|c| c.is_whitespace()).count();
    let mut end_idx: isize = lines.len() as isize;
    for i in (start_idx as usize + 1)..lines.len() {
        let line = &lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();
        if indent_len <= header_indent_len && trimmed.ends_with(':') {
            end_idx = i as isize;
            break;
        }
    }

    let slot_re = Regex::new(r"^\s*slot[_\s]*(\d+):\s*(.*)$").map_err(|e| e.to_string())?;
    let mut entries: Vec<ExportedSlotEntry> = Vec::new();

    for i in (start_idx as usize + 1)..(end_idx as usize) {
        let line = &lines[i];
        if let Some(caps) = slot_re.captures(line) {
            let n = caps.get(1).unwrap().as_str().parse::<u32>().unwrap_or(0);
            if n >= a && n <= b {
                let val = caps.get(2).map(|m| m.as_str()).unwrap_or("").to_string();
                entries.push(ExportedSlotEntry { slot: n, value: val });
            }
        }
    }
    entries.sort_by_key(|e| e.slot);
    let count = entries.len() as u32;

    Ok(SaveExportSlotsResponse { target, entries, count })
}


pub fn save_compact_slots(req: SaveCompactSlotsRequest) -> Result<SaveCompactSlotsResponse, String> {
    let mut yaml_text = req.yaml_text.replace('\r', "");
    let target = req.target.to_lowercase();
    if target != "backpack" && target != "bank" && target != "vault" {
        return Err("target must be backpack|bank|vault".to_string());
    }

    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();
    let section_header = format!("{target}:");

    let mut start_idx: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == section_header {
            start_idx = i as isize;
            break;
        }
    }
    if start_idx < 0 {
        return Ok(SaveCompactSlotsResponse { yaml_text, moved: 0, new_count: 0, start_from: req.start_from.unwrap_or(1) });
    }

    let header_indent_len = lines[start_idx as usize]
        .chars()
        .take_while(|c| c.is_whitespace())
        .count();

    let mut end_idx: isize = lines.len() as isize;
    for i in (start_idx as usize + 1)..lines.len() {
        let line = &lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();
        if indent_len <= header_indent_len && trimmed.ends_with(':') {
            end_idx = i as isize;
            break;
        }
    }

    let slot_re = Regex::new(r"^(\s*)slot[_\s]*(\d+):\s*(.*)$").map_err(|e| e.to_string())?;
    let mut slots: Vec<(u32, String, String)> = Vec::new(); // (slot#, indent, value)
    for i in (start_idx as usize + 1)..(end_idx as usize) {
        let line = &lines[i];
        if let Some(caps) = slot_re.captures(line) {
            let indent = caps.get(1).map(|m| m.as_str()).unwrap_or("").to_string();
            let n = caps.get(2).unwrap().as_str().parse::<u32>().unwrap_or(0);
            let val = caps.get(3).map(|m| m.as_str()).unwrap_or("").to_string();
            if n > 0 {
                slots.push((n, indent, val));
            }
        }
    }

    if slots.is_empty() {
        return Ok(SaveCompactSlotsResponse { yaml_text, moved: 0, new_count: 0, start_from: req.start_from.unwrap_or(1) });
    }

    let preserve = req.preserve_order.unwrap_or(true);
    if preserve {
        slots.sort_by_key(|(n, _, _)| *n);
    }

    let start_from = req.start_from.unwrap_or(1).max(1);
    let mut new_lines_for_section: Vec<String> = Vec::new();
    let mut moved: u32 = 0;
    for (idx, (old_slot, indent, val)) in slots.iter().enumerate() {
        let new_slot = start_from + idx as u32;
        if *old_slot != new_slot {
            moved += 1;
        }
        new_lines_for_section.push(format!("{indent}slot_{new_slot}: {val}"));
    }

    // rebuild output, removing all existing slot lines and inserting compacted ones
    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    for (i, line) in lines.iter().enumerate() {
        if (i as isize) > start_idx && (i as isize) < end_idx {
            // skip original slot lines
            if slot_re.is_match(line) {
                continue;
            }
        }
        out.push(line.clone());
        // insert new lines right after header line
        if i as isize == start_idx {
            for nl in &new_lines_for_section {
                out.push(nl.clone());
            }
        }
    }

    yaml_text = out.join("\n");
    Ok(SaveCompactSlotsResponse {
        yaml_text,
        moved,
        new_count: new_lines_for_section.len() as u32,
        start_from,
    })
}


pub fn save_clear_slots_range(req: SaveClearSlotsRequest) -> Result<SaveClearSlotsResponse, String> {
    let mut yaml_text = req.yaml_text.replace('\r', "");
    let target = req.target.to_lowercase();
    if target != "backpack" && target != "bank" && target != "vault" {
        return Err("target must be backpack|bank|vault".to_string());
    }
    if req.start_slot == 0 || req.end_slot == 0 {
        return Err("slot numbers must be >= 1".to_string());
    }
    let (a, b) = if req.start_slot <= req.end_slot {
        (req.start_slot, req.end_slot)
    } else {
        (req.end_slot, req.start_slot)
    };

    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();
    let section_header = format!("{target}:");

    let mut start_idx: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == section_header {
            start_idx = i as isize;
            break;
        }
    }
    if start_idx < 0 {
        // no section => nothing removed
        return Ok(SaveClearSlotsResponse { yaml_text, removed: 0 });
    }

    let header_indent_len = lines[start_idx as usize]
        .chars()
        .take_while(|c| c.is_whitespace())
        .count();

    let mut end_idx: isize = lines.len() as isize;
    for i in (start_idx as usize + 1)..lines.len() {
        let line = &lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();
        if indent_len <= header_indent_len && trimmed.ends_with(':') {
            end_idx = i as isize;
            break;
        }
    }

    let slot_re = Regex::new(r"^slot[_\s]*(\d+):").map_err(|e| e.to_string())?;
    let mut removed: u32 = 0;

    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    for (i, line) in lines.iter().enumerate() {
        if (i as isize) > start_idx && (i as isize) < end_idx {
            let trimmed = line.trim();
            if let Some(caps) = slot_re.captures(trimmed) {
                if let Some(m) = caps.get(1) {
                    if let Ok(n) = m.as_str().parse::<u32>() {
                        if n >= a && n <= b {
                            removed += 1;
                            continue; // drop this line
                        }
                    }
                }
            }
        }
        out.push(line.clone());
    }

    yaml_text = out.join("\n");
    Ok(SaveClearSlotsResponse { yaml_text, removed })
}


pub fn save_plan_free_slots(req: SavePlanSlotsRequest) -> Result<SavePlanSlotsResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();
    let target = req.target.to_lowercase();
    if target != "backpack" && target != "bank" && target != "vault" {
        return Err("target must be backpack|bank|vault".to_string());
    }
    let section_header = format!("{target}:");

    // find section start
    let mut start_idx: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == section_header {
            start_idx = i as isize;
            break;
        }
    }
    // If section doesn't exist, suggest starting from 1
    if start_idx < 0 {
        let count = req.count.max(1);
        let start_from = req.start_from.unwrap_or(1);
        let slots = (0..count).map(|i| start_from + i).collect::<Vec<u32>>();
        return Ok(SavePlanSlotsResponse {
            target,
            first_slot: start_from,
            scanned_up_to: start_from + count,
            slots,
        });
    }

    let header_indent = lines[start_idx as usize]
        .chars()
        .take_while(|c| c.is_whitespace())
        .collect::<String>();
    let header_indent_len = header_indent.len();

    // determine section end: next line with indent <= header indent and ends with ':' (new section header)
    let mut end_idx: isize = lines.len() as isize;
    for i in (start_idx as usize + 1)..lines.len() {
        let line = &lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();
        if indent_len <= header_indent_len && trimmed.ends_with(':') {
            end_idx = i as isize;
            break;
        }
    }

    let slot_re = Regex::new(r"^slot[_\s]*(\d+):").map_err(|e| e.to_string())?;
    let mut used = std::collections::HashSet::<u32>::new();
    for i in (start_idx as usize + 1)..(end_idx as usize) {
        let trimmed = lines[i].trim();
        if let Some(caps) = slot_re.captures(trimmed) {
            if let Some(m) = caps.get(1) {
                if let Ok(n) = m.as_str().parse::<u32>() {
                    used.insert(n);
                }
            }
        }
    }

    let count = req.count.max(1);
    let start_from = req.start_from.unwrap_or(1);
    let max_scan = req.max_scan.unwrap_or(5000);

    let mut slots = Vec::with_capacity(count as usize);
    let mut cursor = start_from;
    while cursor <= max_scan && (slots.len() as u32) < count {
        if !used.contains(&cursor) {
            slots.push(cursor);
        }
        cursor += 1;
    }
    if slots.is_empty() {
        return Err("No free slots found in scan range".to_string());
    }

    Ok(SavePlanSlotsResponse {
        target,
        first_slot: slots[0],
        scanned_up_to: cursor.saturating_sub(1),
        slots,
    })
}


pub fn sav_probe_file(path: String) -> Result<SavProbeResponse, String> {
    let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
    let file_size = bytes.len() as u64;

    let mut hasher = sha2::Sha256::new();
    use sha2::Digest;
    hasher.update(&bytes);
    let sha256 = hex::encode(hasher.finalize());

    let first = bytes.iter().take(16).copied().collect::<Vec<u8>>();
    let first16_hex = hex::encode(&first);
    let first16_ascii = first
        .iter()
        .map(|b| {
            let c = *b as char;
            if c.is_ascii_graphic() || c == ' ' { c } else { '.' }
        })
        .collect::<String>();

    let magic_guess = if bytes.len() >= 4 {
        let m4 = &bytes[0..4];
        match m4 {
            b"GVAS" => "Looks like Unreal Engine GVAS header (guess)".to_string(),
            b"OAKS" => "Looks like OAKS magic (guess)".to_string(),
            _ => format!("Unknown magic: {}", hex::encode(m4)),
        }
    } else {
        "File too small".to_string()
    };

    Ok(SavProbeResponse {
        path,
        file_size,
        sha256,
        first16_hex,
        first16_ascii,
        magic_guess,
    })
}

/// Write binary file to disk.
#[tauri::command]
pub fn write_binary_file(path: String, bytes: Vec<u8>) -> Result<(), String> {
    // Safety: create a timestamped backup when overwriting existing files.
    if std::path::Path::new(&path).exists() {
        let ts = chrono::Local::now().format("%Y%m%d_%H%M%S").to_string();
        let backup = format!("{path}.bak_{ts}");
        std::fs::copy(&path, &backup).map_err(|e| e.to_string())?;
    }
    std::fs::write(&path, bytes).map_err(|e| e.to_string())?;
    Ok(())
}

/// Decrypt a Borderlands .sav file into YAML text using the legacy remote API.
#[tauri::command]
pub async fn save_decrypt_sav_file(req: SaveDecryptRequest) -> Result<SaveDecryptResponse, String> {
    let bytes = std::fs::read(&req.path).map_err(|e| e.to_string())?;
    let b64 = base64::engine::general_purpose::STANDARD.encode(bytes);

    let body = serde_json::json!({
        "command": "decrypt",
        "steamid": req.steamid,
        "sav_data": b64
    });

    let client = reqwest::Client::new();
    let res = client
        .post(SAVE_API_URL)
        .json(&body)
        .send().await.map_err(|e| e.to_string())?;

    let status = res.status();
    let text = res.text().await.map_err(|e| e.to_string())?;
    let data: serde_json::Value = serde_json::from_str(&text).map_err(|e| format!("Invalid JSON ({}): {}", status, e))?;

    if data.get("success").and_then(|v| v.as_bool()).unwrap_or(false) {
        let yaml_text = data
            .get("yaml_content")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .or_else(|| {
                data.get("yaml_data").map(|v| serde_json::to_string_pretty(v).unwrap_or_default())
            })
            .unwrap_or_default();

        let file_name = std::path::Path::new(&req.path)
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_else(|| "save.sav".to_string());

        Ok(SaveDecryptResponse {
            path: req.path,
            file_name,
            yaml_text,
        })
    } else {
        let err = data.get("error")
            .and_then(|v| v.as_str())
            .or_else(|| data.get("message").and_then(|v| v.as_str()))
            .unwrap_or("Failed to decrypt save file");
        Err(err.to_string())
    }
}


/// Decrypt a .sav file using the offline Rust codec (planned).
#[tauri::command]
pub fn save_decrypt_sav_file_offline(req: SaveDecryptRequest) -> Result<SaveDecryptResponse, String> {
    let bytes = std::fs::read(&req.path).map_err(|e| e.to_string())?;
    let decoded = crate::engine::save_codec::decode_offline(&bytes, &req.steamid)?;
    let file_name = std::path::Path::new(&req.path)
        .file_name()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| "save.sav".to_string());
    Ok(SaveDecryptResponse {
        path: req.path,
        file_name,
        yaml_text: decoded.yaml_text,
    })
}

/// Encrypt YAML into .sav bytes using the offline Rust codec (planned).
#[tauri::command]
pub fn save_encrypt_yaml_offline(req: SaveEncryptRequest) -> Result<SaveEncryptResponse, String> {
    let enc = crate::engine::save_codec::encode_offline(&req.yaml_text, &req.steamid)?;
    Ok(SaveEncryptResponse { sav_bytes: enc.sav_bytes })
}


#[derive(Debug, Serialize, Deserialize)]
pub struct SaveAutoDecryptRequest {
    pub path: String,
    pub steamid: String,
    pub prefer_offline: Option<bool>,
    pub allow_remote_fallback: Option<bool>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SaveAutoEncryptRequest {
    pub steamid: String,
    pub yaml_text: String,
    pub prefer_offline: Option<bool>,
    pub allow_remote_fallback: Option<bool>,
}

/// Auto decrypt: tries offline codec (if preferred), otherwise uses remote API fallback if allowed.
#[tauri::command]
pub async fn save_decrypt_sav_file_auto(req: SaveAutoDecryptRequest) -> Result<SaveDecryptResponse, String> {
    let cfg = load_config().unwrap_or_default();
    let prefer_offline = req.prefer_offline.unwrap_or(cfg.prefer_offline);
    let allow_remote = req.allow_remote_fallback.unwrap_or(cfg.allow_remote_fallback);

    if prefer_offline {
        let offline = save_decrypt_sav_file_offline(SaveDecryptRequest { path: req.path.clone(), steamid: req.steamid.clone() });
        match offline {
            Ok(v) => return Ok(v),
            Err(e) => {
                if !allow_remote {
                    return Err(format!("Offline codec failed and remote fallback disabled: {e}"));
                }
            }
        }
    }

    if !allow_remote {
        return Err("Remote fallback disabled (and offline codec not used).".to_string());
    }

    save_decrypt_sav_file(SaveDecryptRequest { path: req.path, steamid: req.steamid }).await
}

/// Auto encrypt: tries offline codec (if preferred), otherwise uses remote API fallback if allowed.
#[tauri::command]
pub async fn save_encrypt_yaml_auto(req: SaveAutoEncryptRequest) -> Result<SaveEncryptResponse, String> {
    let cfg = load_config().unwrap_or_default();
    let prefer_offline = req.prefer_offline.unwrap_or(cfg.prefer_offline);
    let allow_remote = req.allow_remote_fallback.unwrap_or(cfg.allow_remote_fallback);

    if prefer_offline {
        let offline = save_encrypt_yaml_offline(SaveEncryptRequest { steamid: req.steamid.clone(), yaml_text: req.yaml_text.clone() });
        match offline {
            Ok(v) => return Ok(v),
            Err(e) => {
                if !allow_remote {
                    return Err(format!("Offline codec failed and remote fallback disabled: {e}"));
                }
            }
        }
    }

    if !allow_remote {
        return Err("Remote fallback disabled (and offline codec not used).".to_string());
    }

    save_encrypt_yaml(SaveEncryptRequest { steamid: req.steamid, yaml_text: req.yaml_text }).await
}

/// Encrypt YAML text back into Borderlands .sav bytes using the legacy remote API.
#[tauri::command]
pub async fn save_encrypt_yaml(req: SaveEncryptRequest) -> Result<SaveEncryptResponse, String> {
    let body = serde_json::json!({
        "command": "encrypt",
        "steamid": req.steamid,
        "yaml_content": req.yaml_text,
        "yaml_data": req.yaml_text
    });

    let client = reqwest::Client::new();
    let res = client
        .post(SAVE_API_URL)
        .json(&body)
        .send().await.map_err(|e| e.to_string())?;

    let status = res.status();
    let text = res.text().await.map_err(|e| e.to_string())?;
    let data: serde_json::Value = serde_json::from_str(&text).map_err(|e| format!("Invalid JSON ({}): {}", status, e))?;

    // Encrypted data can appear under multiple keys per legacy HTML
    let encrypted_opt = data.get("encrypted")
        .or_else(|| data.get("encrypted_data"))
        .or_else(|| data.get("sav_data"))
        .or_else(|| data.get("data"));

    if data.get("success").and_then(|v| v.as_bool()).unwrap_or(false) {
        if let Some(enc) = encrypted_opt.and_then(|v| v.as_str()) {
            let bytes = base64::engine::general_purpose::STANDARD
                .decode(enc)
                .map_err(|e| e.to_string())?;
            Ok(SaveEncryptResponse { sav_bytes: bytes })
        } else {
            Err(format!("API success but no encrypted data field ({}).", status))
        }
    } else {
        let err = data.get("error")
            .and_then(|v| v.as_str())
            .or_else(|| data.get("message").and_then(|v| v.as_str()))
            .or_else(|| data.get("reason").and_then(|v| v.as_str()))
            .unwrap_or("Failed to encrypt save file");
        Err(err.to_string())
    }
}


/// Extract serials with location/slot/state_flags similar to legacy save parsing.
/// It performs a first pass to map `state_flags` by slot and `in_machine` by serial (lost loot).
/// Then a second pass emits serial records with location + slot metadata.
#[tauri::command]
pub fn save_extract_serials_with_location(yamlText: String) -> Result<SaveExtractResponse, String> {
    let lines: Vec<&str> = yamlText.lines().collect();

    let slot_re = Regex::new(r"^slot[_\s]*(\d+):").map_err(|e| e.to_string())?;
    let state_flags_re = Regex::new(r"^(state_flags|flags):\s*(\d+)").map_err(|e| e.to_string())?;
    let in_machine_re = Regex::new(r"^in_machine:\s*(true|false)").map_err(|e| e.to_string())?;
    let serial_re = Regex::new(r"@Ug[^\s\r\n'\";,:]+").map_err(|e| e.to_string())?;

    // First pass: state_flags by slot for backpack/equipped, in_machine for lost_loot
    let mut state_flags_by_slot: std::collections::HashMap<String, i64> = std::collections::HashMap::new();
    let mut in_machine_by_serial: std::collections::HashMap<String, bool> = std::collections::HashMap::new();

    let mut current_location = "unknown".to_string();
    let mut current_slot: Option<i32> = None;

    for line in &lines {
        let trimmed = line.trim();
        let lower = trimmed.to_lowercase();

        // crude location transitions (matches intent of legacy)
        if lower.starts_with("backpack") {
            current_location = "backpack".to_string();
            current_slot = None;
        } else if lower.starts_with("equipped") {
            current_location = "equipped".to_string();
            current_slot = None;
        } else if lower.contains("lost_loot") || lower.contains("lostloot") {
            current_location = "lost_loot".to_string();
            current_slot = None;
        } else if lower.starts_with("bank") {
            current_location = "bank".to_string();
            current_slot = None;
        } else if lower.starts_with("vault") {
            current_location = "vault".to_string();
            current_slot = None;
        } else if lower.starts_with("rewards") || lower.starts_with("reward") {
            current_location = "rewards".to_string();
            current_slot = None;
        } else if lower.contains("unknown_items") {
            current_location = "unknown_items".to_string();
            current_slot = None;
        }

        if let Some(cap) = slot_re.captures(trimmed) {
            if current_location == "backpack" || current_location == "equipped" {
                let s = cap.get(1).unwrap().as_str().parse::<i32>().ok();
                current_slot = s;
            }
        }

        if let Some(cap) = state_flags_re.captures(trimmed) {
            if (current_location == "backpack" || current_location == "equipped") && current_slot.is_some() {
                let val = cap.get(2).unwrap().as_str().parse::<i64>().ok();
                if let Some(v) = val {
                    let key = format!("{}_{}", current_location, current_slot.unwrap());
                    // prefer state_flags over flags; but we store whatever we saw last.
                    state_flags_by_slot.insert(key, v);
                }
            }
        }

        // lost loot in_machine mapping requires a serial to associate with; we use "closest" serial on same line if present.
        if current_location == "lost_loot" {
            if let Some(cap) = in_machine_re.captures(trimmed) {
                let v = cap.get(1).unwrap().as_str() == "true";
                // if line has a serial too, associate
                if let Some(scap) = serial_re.find(trimmed) {
                    in_machine_by_serial.insert(scap.as_str().to_string(), v);
                }
            }
        }
    }

    // Second pass: extract serials with metadata
    let mut serials_with_location: Vec<SerialWithLocation> = Vec::new();
    current_location = "unknown".to_string();
    current_slot = None;

    let skip_locations: std::collections::HashSet<&'static str> =
        ["rewards", "unknown_items"].into_iter().collect();

    for line in &lines {
        let trimmed = line.trim();
        let lower = trimmed.to_lowercase();

        if lower.starts_with("backpack") {
            current_location = "backpack".to_string();
            current_slot = None;
        } else if lower.starts_with("equipped") {
            current_location = "equipped".to_string();
            current_slot = None;
        } else if lower.contains("lost_loot") || lower.contains("lostloot") {
            current_location = "lost_loot".to_string();
            current_slot = None;
        } else if lower.starts_with("bank") {
            current_location = "bank".to_string();
            current_slot = None;
        } else if lower.starts_with("vault") {
            current_location = "vault".to_string();
            current_slot = None;
        } else if lower.starts_with("rewards") || lower.starts_with("reward") {
            current_location = "rewards".to_string();
            current_slot = None;
        } else if lower.contains("unknown_items") {
            current_location = "unknown_items".to_string();
            current_slot = None;
        }

        if let Some(cap) = slot_re.captures(trimmed) {
            if current_location == "backpack" || current_location == "equipped" {
                current_slot = cap.get(1).unwrap().as_str().parse::<i32>().ok();
            }
        }

        for m in serial_re.find_iter(line) {
            let mut serial = m.as_str().to_string();
            serial = serial.trim_end_matches(&['"', '\''][..]).to_string();

            if !is_valid_base85(&serial) {
                continue;
            }

            if skip_locations.contains(current_location.as_str()) {
                continue;
            }

            let state_flags = if (current_location == "backpack" || current_location == "equipped")
                && current_slot.is_some()
            {
                let key = format!("{}_{}", current_location, current_slot.unwrap());
                state_flags_by_slot.get(&key).copied()
            } else {
                None
            };

            let in_machine = if current_location == "lost_loot" {
                Some(*in_machine_by_serial.get(&serial).unwrap_or(&false))
            } else {
                None
            };

            serials_with_location.push(SerialWithLocation {
                serial,
                index: serials_with_location.len(),
                location: current_location.clone(),
                slot: current_slot,
                state_flags,
                in_machine,
            });
        }
    }

    // Deduplicate serials preferring entries with better metadata, as legacy does.
    let mut unique: std::collections::HashMap<String, SerialWithLocation> = std::collections::HashMap::new();
    for s in serials_with_location.into_iter() {
        unique
            .entry(s.serial.clone())
            .and_modify(|existing| {
                // Prefer non-unknown location
                if existing.location == "unknown" && s.location != "unknown" {
                    *existing = s.clone();
                    return;
                }
                // Prefer slot filled when same location
                if existing.location == s.location && existing.slot.is_none() && s.slot.is_some() {
                    *existing = s.clone();
                    return;
                }
                // Prefer state_flags if missing
                if existing.state_flags.is_none() && s.state_flags.is_some() {
                    existing.state_flags = s.state_flags;
                }
                // Prefer in_machine if missing
                if existing.in_machine.is_none() && s.in_machine.is_some() {
                    existing.in_machine = s.in_machine;
                }
            })
            .or_insert(s);
    }

    let mut out: Vec<SerialWithLocation> = unique.into_values().collect();
    out.sort_by_key(|x| x.index);

    Ok(SaveExtractResponse {
        unique_count: out.len(),
        serials: out,
    })
}

/// Replace or create a `backpack:` YAML section with provided slots.
/// This mirrors the legacy "rebuild backpack section" approach by working line-based to preserve formatting.
#[tauri::command]
pub fn save_set_backpack_slots(req: SaveUpdateBackpackRequest) -> Result<SaveUpdateBackpackResponse, String> {
    let mut yaml_content = req.yaml_text.replace('\r', "");
    let mut lines: Vec<String> = yaml_content.lines().map(|l| l.to_string()).collect();

    // Find backpack section start (line with 'backpack:')
    let mut backpack_start: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == "backpack:" {
            backpack_start = i as isize;
            break;
        }
    }

    // Determine end of backpack section following legacy intent:
    // end when indent decreases <= backpack indent and line indicates new section (equipped, rewards, lostloot, bank, vault, items:)
    let mut backpack_end: isize = -1;
    let mut unknown_items_index: isize = -1;

    if backpack_start >= 0 {
        let backpack_indent = lines[backpack_start as usize]
            .chars()
            .take_while(|c| c.is_whitespace())
            .collect::<String>();
        let backpack_indent_len = backpack_indent.len();

        for i in (backpack_start as usize + 1)..lines.len() {
            let line = &lines[i];
            let trimmed = line.trim();
            let lower = trimmed.to_lowercase();
            let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();

            if lower.starts_with("unknown_items") && unknown_items_index == -1 {
                unknown_items_index = i as isize;
            }

            let is_slot_line = Regex::new(r"^slot[_\s]*\d+:").unwrap().is_match(trimmed);
            let is_serial_line = trimmed.starts_with("serial:");
            let is_flags_line = trimmed.starts_with("flags:") || trimmed.starts_with("state_flags:");

            if indent_len <= backpack_indent_len
                && !is_slot_line
                && !is_serial_line
                && !is_flags_line
                && (lower.starts_with("equipped")
                    || lower.starts_with("rewards")
                    || lower.starts_with("reward")
                    || lower.starts_with("lostloot")
                    || lower.starts_with("lost_loot")
                    || lower.starts_with("bank")
                    || lower.starts_with("vault")
                    || lower.starts_with("items:")
                    || (lower.contains(':') && indent_len == backpack_indent_len))
            {
                if unknown_items_index == -1 {
                    backpack_end = i as isize;
                }
                break;
            }
        }

        if backpack_end == -1 {
            backpack_end = lines.len() as isize;
        }
    }

    // Build slot lines
    let make_backpack_lines = |backpack_indent: &str| -> Vec<String> {
        let slot_indent = format!("{backpack_indent}  ");
        let serial_indent = format!("{slot_indent}  ");
        let mut out = Vec::new();
        for s in &req.slots {
            out.push(format!("{slot_indent}slot_{}:", s.slot));
            out.push(format!("{serial_indent}serial: '{}'", s.serial));
            if let Some(f) = s.flags {
                out.push(format!("{serial_indent}flags: {}", f));
            }
            if let Some(sf) = s.state_flags {
                out.push(format!("{serial_indent}state_flags: {}", sf));
            }
        }
        out
    };

    if backpack_start == -1 {
        // Add backpack at end with default indent 4 spaces
        let backpack_indent = "    ";
        lines.push(String::new());
        lines.push(format!("{backpack_indent}backpack:"));
        lines.extend(make_backpack_lines(backpack_indent));
    } else {
        let backpack_indent = lines[backpack_start as usize]
            .chars()
            .take_while(|c| c.is_whitespace())
            .collect::<String>();

        let before = lines[..(backpack_start as usize + 1)].to_vec();
        let after = lines[(backpack_end as usize)..].to_vec();

        let mut rebuilt = Vec::new();
        rebuilt.extend(before);
        // insert slots before unknown_items if it exists within backpack block (legacy)
        let mut slot_lines = make_backpack_lines(&backpack_indent);
        rebuilt.append(&mut slot_lines);
        rebuilt.extend(after);

        lines = rebuilt;
    }

    yaml_content = lines.join("\n");
    Ok(SaveUpdateBackpackResponse { yaml_text: yaml_content })
}


/// Replace or create an `equipped:` YAML section with provided slots.
#[tauri::command]
pub fn save_set_equipped_slots(req: SaveUpdateEquippedRequest) -> Result<SaveUpdateBackpackResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();

    // Determine indent by existing section if present, else default 4 spaces.
    let section_name = "equipped";
    let mut indent = "    ".to_string();
    for line in &lines {
        if line.trim().to_lowercase() == "equipped:" {
            indent = line.chars().take_while(|c| c.is_whitespace()).collect::<String>();
            break;
        }
    }

    let slot_indent = format!("{indent}  ");
    let field_indent = format!("{slot_indent}  ");
    let mut section_lines = Vec::new();
    for s in &req.slots {
        section_lines.push(format!("{slot_indent}slot_{}:", s.slot));
        section_lines.push(format!("{field_indent}serial: '{}'", s.serial));
        if let Some(sf) = s.state_flags {
            section_lines.push(format!("{field_indent}state_flags: {}", sf));
        }
    }

    let out_lines = replace_yaml_section(&lines, section_name, section_lines);
    Ok(SaveUpdateBackpackResponse { yaml_text: out_lines.join("\n") })
}

/// Replace or create `lost_loot:` section entries (simplified). Writes list items with serial + in_machine.
/// Note: legacy structure may differ; this is an engine-level primitive we can refine once we validate the exact YAML shape.
#[tauri::command]
pub fn save_set_lost_loot(req: SaveUpdateLostLootRequest) -> Result<SaveUpdateBackpackResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();

    let section_name = "lost_loot";
    let mut indent = "    ".to_string();
    for line in &lines {
        if line.trim().to_lowercase() == "lost_loot:" || line.trim().to_lowercase() == "lostloot:" {
            indent = line.chars().take_while(|c| c.is_whitespace()).collect::<String>();
            break;
        }
    }

    let item_indent = format!("{indent}  ");
    let field_indent = format!("{item_indent}  ");
    let mut section_lines = Vec::new();

    for e in &req.entries {
        section_lines.push(format!("{item_indent}-"));
        section_lines.push(format!("{field_indent}serial: '{}'", e.serial));
        if let Some(im) = e.in_machine {
            section_lines.push(format!("{field_indent}in_machine: {}", if im { "true" } else { "false" }));
        }
    }

    let out_lines = replace_yaml_section(&lines, section_name, section_lines);
    Ok(SaveUpdateBackpackResponse { yaml_text: out_lines.join("\n") })
}


/// Replace or create a `bank:` YAML section with provided slots (slot_# with serial/flags/state_flags).
#[tauri::command]
pub fn save_set_bank_slots(req: SaveUpdateBackpackRequest) -> Result<SaveUpdateBackpackResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();

    let section_name = "bank";
    let mut indent = "    ".to_string();
    for line in &lines {
        if line.trim().to_lowercase() == "bank:" {
            indent = line.chars().take_while(|c| c.is_whitespace()).collect::<String>();
            break;
        }
    }

    let slot_indent = format!("{indent}  ");
    let field_indent = format!("{slot_indent}  ");
    let mut section_lines = Vec::new();
    for s in &req.slots {
        section_lines.push(format!("{slot_indent}slot_{}:", s.slot));
        section_lines.push(format!("{field_indent}serial: '{}'", s.serial));
        if let Some(f) = s.flags {
            section_lines.push(format!("{field_indent}flags: {}", f));
        }
        if let Some(sf) = s.state_flags {
            section_lines.push(format!("{field_indent}state_flags: {}", sf));
        }
    }

    let out_lines = replace_yaml_section(&lines, section_name, section_lines);
    Ok(SaveUpdateBackpackResponse { yaml_text: out_lines.join("\n") })
}

/// Replace or create a `vault:` YAML section with provided slots (slot_# with serial/flags/state_flags).
#[tauri::command]
pub fn save_set_vault_slots(req: SaveUpdateBackpackRequest) -> Result<SaveUpdateBackpackResponse, String> {
    let yaml_text = req.yaml_text.replace('\r', "");
    let lines: Vec<String> = yaml_text.lines().map(|l| l.to_string()).collect();

    let section_name = "vault";
    let mut indent = "    ".to_string();
    for line in &lines {
        if line.trim().to_lowercase() == "vault:" {
            indent = line.chars().take_while(|c| c.is_whitespace()).collect::<String>();
            break;
        }
    }

    let slot_indent = format!("{indent}  ");
    let field_indent = format!("{slot_indent}  ");
    let mut section_lines = Vec::new();
    for s in &req.slots {
        section_lines.push(format!("{slot_indent}slot_{}:", s.slot));
        section_lines.push(format!("{field_indent}serial: '{}'", s.serial));
        if let Some(f) = s.flags {
            section_lines.push(format!("{field_indent}flags: {}", f));
        }
        if let Some(sf) = s.state_flags {
            section_lines.push(format!("{field_indent}state_flags: {}", sf));
        }
    }

    let out_lines = replace_yaml_section(&lines, section_name, section_lines);
    Ok(SaveUpdateBackpackResponse { yaml_text: out_lines.join("\n") })
}

/// Deserialize a Base85 serial using the legacy API (temporary).
/// This mirrors the HTML behavior calling borderlands.be/nicnl/api.php with {serial_b85}.
#[tauri::command]
pub async fn deserialize_base85(req: DeserializeRequest) -> Result<DeserializeResponse, String> {
    if !is_valid_base85(&req.serial_b85) {
        return Ok(DeserializeResponse {
            serial: None,
            error: Some("Invalid Base85 serial".to_string()),
        });
    }

    let client = reqwest::Client::new();
    let res = client
        .post(LEGACY_API_URL)
        .json(&req)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    let status = res.status();
    let text = res.text().await.map_err(|e| e.to_string())?;

    // API returns JSON; be defensive
    let parsed: serde_json::Value =
        serde_json::from_str(&text).map_err(|e| format!("Bad API JSON: {e} | {text}"))?;

    if !status.is_success() {
        return Ok(DeserializeResponse {
            serial: None,
            error: Some(format!("API error: HTTP {status}")),
        });
    }

    let serial = parsed
        .get("serial")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    let error = parsed
        .get("error")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    Ok(DeserializeResponse { serial, error })
}

/// Serialize a decoded serial string to Base85 using the legacy API (temporary).
#[tauri::command]
pub async fn serialize_decoded(req: SerializeRequest) -> Result<SerializeResponse, String> {
    let decoded = req.decoded.trim();
    if decoded.is_empty() {
        return Ok(SerializeResponse {
            serial_b85: None,
            error: Some("Decoded serial is empty".to_string()),
        });
    }

    let client = reqwest::Client::new();
    let res = client
        .post(LEGACY_API_URL)
        .json(&req)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    let status = res.status();
    let text = res.text().await.map_err(|e| e.to_string())?;

    let parsed: serde_json::Value =
        serde_json::from_str(&text).map_err(|e| format!("Bad API JSON: {e} | {text}"))?;

    if !status.is_success() {
        return Ok(SerializeResponse {
            serial_b85: None,
            error: Some(format!("API error: HTTP {status}")),
        });
    }

    let serial_b85 = parsed
        .get("serial_b85")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    let error = parsed
        .get("error")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    Ok(SerializeResponse { serial_b85, error })
}

/// Bulk deserialize: takes pasted text, extracts serials, returns decoded lines.
#[tauri::command]
pub async fn bulk_deserialize(text: String) -> Result<BulkConvertResponse, String> {
    let parsed = parse_bulk_input(text)?;
    let mut output = Vec::new();
    let mut ok = 0usize;
    let mut failed = 0usize;

    for s in parsed.serials {
        if s.starts_with("@Ug") {
            let res = deserialize_base85(DeserializeRequest { serial_b85: s.clone() }).await?;
            if let Some(decoded) = res.serial {
                ok += 1;
                output.push(decoded);
            } else {
                failed += 1;
                output.push(format!("# FAILED: {s}"));
            }
        } else if is_decoded_serial(&s) {
            // already decoded
            ok += 1;
            output.push(ensure_trailing_pipe(s)?);
        } else {
            failed += 1;
            output.push(format!("# SKIP: {s}"));
        }
    }

    Ok(BulkConvertResponse { output_lines: output, ok, failed })
}

/// Bulk serialize: takes pasted text (decoded lines or base85), returns base85 lines.
#[tauri::command]
pub async fn bulk_serialize(text: String) -> Result<BulkConvertResponse, String> {
    let parsed = parse_bulk_input(text)?;
    let mut output = Vec::new();
    let mut ok = 0usize;
    let mut failed = 0usize;

    for s in parsed.serials {
        if s.starts_with("@Ug") {
            ok += 1;
            output.push(s);
        } else if is_decoded_serial(&s) {
            let decoded = ensure_trailing_pipe(s)?;
            let res = serialize_decoded(SerializeRequest { decoded }).await?;
            if let Some(b85) = res.serial_b85 {
                ok += 1;
                output.push(b85);
            } else {
                failed += 1;
                output.push(format!("# FAILED: {}", decoded));
            }
        } else {
            failed += 1;
            output.push(format!("# SKIP: {s}"));
        }
    }

    Ok(BulkConvertResponse { output_lines: output, ok, failed })
}

#[tauri::command]
pub fn brick_roll(req: BrickRollRequest) -> Result<BrickRollResponse, String> {
    let mut breakdown = Vec::new();
    breakdown.push(format!("Seed: {}", req.seed));
    breakdown.push(format!("Intensity: {}", req.intensity));
    if let Some(b) = &req.base_code {
        breakdown.push(format!("Remix base provided: {} chars", b.len()));
    } else {
        breakdown.push("Remix base: none".to_string());
    }

    Ok(BrickRollResponse {
        deserialized: Some(format!(
            "BRICK_ROLL_DEMO | seed={} intensity={}",
            req.seed, req.intensity
        )),
        serialized: None,
        breakdown: Some(breakdown.join("\n")),
    })
}



fn replace_yaml_section(
    lines: &[String],
    section_name: &str,
    section_lines: Vec<String>,
) -> Vec<String> {
    // Find section start by exact trimmed match: "<section_name>:"
    let mut start: isize = -1;
    for (i, line) in lines.iter().enumerate() {
        if line.trim().to_lowercase() == format!("{}:", section_name.to_lowercase()) {
            start = i as isize;
            break;
        }
    }

    if start == -1 {
        // Add section at end with default indent (4 spaces)
        let indent = "    ";
        let mut out = lines.to_vec();
        if !out.is_empty() && !out.last().unwrap().is_empty() {
            out.push(String::new());
        }
        out.push(format!("{indent}{}:", section_name));
        out.extend(section_lines);
        return out;
    }

    let start_usize = start as usize;
    let section_indent_len = lines[start_usize].chars().take_while(|c| c.is_whitespace()).count();
    let mut end = lines.len();

    // section ends when indent <= section indent and line looks like a new top-level-ish section key
    for i in (start_usize + 1)..lines.len() {
        let line = &lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let indent_len = line.chars().take_while(|c| c.is_whitespace()).count();
        if indent_len <= section_indent_len && trimmed.ends_with(':') {
            end = i;
            break;
        }
    }

    let mut out = Vec::new();
    out.extend_from_slice(&lines[..(start_usize + 1)]);
    out.extend(section_lines);
    out.extend_from_slice(&lines[end..]);
    out
}

// ---- helpers ----

fn normalize_code(code: &str) -> String {
    let mut s = code.replace('\r', "");
    s = s
        .lines()
        .map(|line| line.trim())
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>()
        .join("\n");
    s
}

fn looks_like_serial(code: &str) -> bool {
    code.starts_with("@Ug") || is_decoded_serial(code)
}

fn is_decoded_serial(s: &str) -> bool {
    let re = Regex::new(r#"^\d+,\s*\d+,\s*\d+,\s*\d+\|?"#).unwrap();
    re.is_match(s.trim())
}

fn is_valid_base85(serial: &str) -> bool {
    if !serial.starts_with("@Ug") || serial.len() < 10 {
        return false;
    }
    let base = &serial[3..];
    let re = Regex::new(r#"^[A-Za-z0-9+/=!$%&*@()\[\]\{\}~`^_<>?#;\-]+$"#).unwrap();
    re.is_match(base)
}

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![
            parse_weapon_code,
            parse_bulk_input,
            ensure_trailing_pipe,
            normalize_bulk_input,
            get_app_config,
            set_app_config,
            game_data_update_on_start,
            game_data_load_cached,
            guide_init,
            guide_index,
            guide_get,
            set_steam_id,
            add_recent_sav,
            add_recent_yaml,
            read_text_file,
            write_text_file,
            read_binary_file,
            sav_probe_file,
            write_binary_file,
            save_decrypt_sav_file,
            save_encrypt_yaml,
            save_decrypt_sav_file_offline,
            save_encrypt_yaml_offline,
            save_decrypt_sav_file_auto,
            save_encrypt_yaml_auto,
            deserialize_base85,
            serialize_decoded,
            bulk_deserialize,
            bulk_serialize,
            save_extract_serials_with_location,
            save_set_backpack_slots,
            save_set_equipped_slots,
            save_set_lost_loot,
            save_set_bank_slots,
            save_set_vault_slots,
            save_plan_free_slots,
            save_clear_slots_range,
            save_compact_slots,
            save_export_slots_range,
            save_import_slots,
            brick_roll
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
