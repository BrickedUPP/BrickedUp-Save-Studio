Engine API (Tauri Commands)
==========================

This document defines the stable command surface the UI calls.
The goal is to keep UI logic thin and move all game/weapon/save logic into the Rust engine.

Implemented
-----------
- parse_bulk_input(text: string) -> { serials[], base85[], decoded[] }
  - Extracts serials from:
    - Base85 lines (@Ug...)
    - Decoded lines (259, 0, 1, 50|...)
    - YAML snippets (serial: '@Ug...')
    - JS object snippets (code: '...')
  - Mirrors the intent of legacy parseBulkInput(). fileciteturn2file8

- ensure_trailing_pipe(s: string) -> string
  - Mirrors legacy ensureTrailingPipe() used by bulk serialization flows. fileciteturn2file2

- normalize_bulk_input(text: string) -> string[]
  - Mirrors legacy normalizeBulkInput(). fileciteturn2file14

- parse_weapon_code(code: string) -> { normalized?, serialized?, breakdown? }
  - Placeholder normalization now; will be replaced with full parsing logic. fileciteturn2file5

- brick_roll(req: {seed, intensity, base_code?}) -> { deserialized?, serialized?, breakdown? }
  - Placeholder now; full Brick Roll comes later.

Planned (next)
--------------
Weapons / Item Codes
- serialize_weapon(decoded: string) -> base85
- deserialize_weapon(base85: string) -> decoded
- parse_item_code(input: string) -> parsed + friendly breakdown
  - Legacy detects Base85 and calls remote API when needed. fileciteturn2file5

Bulk serial tools
- bulk_deserialize_serials(text: string) -> output lines + status
- bulk_serialize_serials(text: string) -> output lines + status
  - Legacy supports multiple input formats and preserves original order. fileciteturn2file14

Save editor
- save_open(path) -> yaml text + metadata
- save_write(path, yaml) -> bytes
- save_update_equipped_slot(...)
- save_update_backpack_slots(...)
- save_mass_add_items(...)
- save_mass_remove_items(...)


Remote conversion (temporary)
-----------------------------
- deserialize_base85(req: {serial_b85}) -> {serial?, error?}
- serialize_decoded(req: {decoded}) -> {serial_b85?, error?}
- bulk_deserialize(text) -> {output_lines[], ok, failed}
- bulk_serialize(text) -> {output_lines[], ok, failed}

These currently call the same remote endpoint used by the legacy HTML:
- POST https://borderlands.be/nicnl/api.php with JSON body {serial_b85} (deserialize) fileciteturn3file0
This will be replaced with an offline Rust implementation later.

Save Editor YAML Ops
--------------------
- save_extract_serials_with_location(yamlText) -> {serials[], unique_count}
  Extracts serials while tracking location/slot/state_flags/in_machine similar to legacy logic. fileciteturn4file8
- save_set_backpack_slots(req: {yaml_text, slots[]}) -> {yaml_text}
  Rebuilds or creates the `backpack:` section using slot indentation rules similar to legacy rebuild logic. fileciteturn4file2

- save_set_equipped_slots(req: {yaml_text, slots[]}) -> {yaml_text}
  Rebuilds/creates equipped section.
- save_set_lost_loot(req: {yaml_text, entries[]}) -> {yaml_text}
  Rebuilds/creates lost_loot section (simplified list form).

- save_set_bank_slots(req: {yaml_text, slots[]}) -> {yaml_text}
- save_set_vault_slots(req: {yaml_text, slots[]}) -> {yaml_text}

File IO
-------
- read_text_file(path) -> {path, content}
- write_text_file({path, content}) -> ()

Save (.sav)
----------
- save_decrypt_sav_file({path, steamid}) -> {path, file_name, yaml_text}
- save_encrypt_yaml({steamid, yaml_text}) -> {sav_bytes[]}
- write_binary_file(path, bytes[]) -> ()

Config
------
- get_app_config() -> {prefer_offline, allow_remote_fallback}
- set_app_config(cfg) -> ()

Auto save helpers
-----------------
- save_decrypt_sav_file_auto({path, steamid, prefer_offline?, allow_remote_fallback?})
- save_encrypt_yaml_auto({steamid, yaml_text, prefer_offline?, allow_remote_fallback?})

Safety
------
- write_binary_file(path, bytes[]) now creates a timestamped backup when overwriting: <path>.bak_YYYYMMDD_HHMMSS

Config additions
---------------
- reopen_last_on_launch: bool
- last_opened_sav_path: string?
- recent_sav_paths/recent_yaml_paths MRU lists

Config additions (v17)
---------------------
- steam_id: string? (stored locally, optional)
- set_steam_id(steamId?) -> updated config

UX
--
- App can redirect to Settings when Steam/Epic ID is missing for auto-open/resume (needSteam=1).

Diagnostics
-----------
- sav_probe_file(path) -> {file_size, sha256, first16_hex, first16_ascii, magic_guess}

Game data
---------
- game_data_update_on_start() -> {updated, sha256, bytes, cached_path}
  Downloads from the remote API and caches locally.
- game_data_load_cached() -> string
  Reads cached game_data_export.json text.

UI
--
- Parts Browser page reads cached game data loaded at startup.

Game data index
---------------
Client-side (TS) indexer builds weapon type/parts lists from cached game_data_export.json.

Parts indexing
--------------
- gameDataIndex now scans every top-level category that has manufacturers and a *_types table with type_id + part_types.

Presets
-------
- Parts Browser supports building a Selected Parts preset and exporting JSON.

Flow
----
- Parts Browser can send a preset to Builder using a shared presetStore (Zustand).

Flow additions (v26)
-------------------
- Builder can send the current Parts preset to Save Editor (in-memory) for copy/append of spawn codes.

Save Editor
-----------
- Apply Serial List: paste Base85 serials and write to Backpack/Bank/Vault slots in YAML.

Save Editor additions (v28)
--------------------------
- Serialize Decoded → Apply: bulk_serialize decoded lines into Base85 serials then apply to Backpack/Bank/Vault slots.

Builder
-------
- Builder can generate a decoded code string matching the original HTML format: "typeId, 0, 1, level| ...".
- This can be pasted into Save Editor's Serialize Decoded → Apply pipeline.

Slot planning
------------
- save_plan_free_slots(yaml_text, target, count) -> suggests free slot numbers by scanning existing slot_* keys.

Save safety (v31)
----------------
- Save Editor apply can skip occupied slots by planning free slots and mapping serials to them.

Slot tools
----------
- save_clear_slots_range(target, start_slot, end_slot): removes slot_* entries in that range.

Slot tools (v33)
---------------
- save_compact_slots(target, start_from, preserve_order): compacts slot_* entries to remove gaps.

Export/import
-------------
- save_export_slots_range(target, start_slot, end_slot): exports slot values to JSON.

- save_import_slots(target, entries, start_slot, skip_occupied): imports exported entries into the chosen section.

UX (v36)
--------
- Slot Tools: one-click transfer from Export JSON to Import JSON (and paste from clipboard).

Macros (v37)
-----------
- Move slots macro: export a range from one section, import into another, optionally clear source.

Macros (v38)
-----------
- Move slots macro can optionally compact destination (and source) after transfer.

UX (v39)
--------
- Move slots macro includes quick presets for common transfers (Backpack↔Bank↔Vault).

Theming
-------
- CSS-variable theme system (Classic / Obsidian / Neon / Rose) with a header toggle.

Branding (v41)
-------------
- App name: BrickedUp Save Studio
- Subtitle: Save & Inventory Editor • by BRICKEDNLOADED
- UI wording pass: Save Editor→Inventory Manager, Slot Tools→Vault Tools, Parts Browser→Parts Library, Output→Export.

Release (v42)
------------
- Version pinned to v1.0.0 across tauri.conf.json, package.json, Cargo.toml.
- Added RELEASE.md + CHANGELOG.md templates.

Guide (v45)
----------
- Local, offline guide bundle stored in app data (guides/index.json + markdown pages).
- New commands: guide_init, guide_index, guide_get.
- Settings: Open Guide.

Build helper (v46)
-----------------
- Added tools/build_windows.bat and tools/build_windows.ps1 for one-click builds.
- Guide: upgraded to markdown rendering + section search.

Brick Roll (v48)
----------------
- Brick Roll now runs in the frontend (TypeScript) using cached game data index.
- It never throws; failures surface as a toast.
- Also attempts to serialize via serialize_decoded (may require online).

Brick Roll (v50)
---------------
- Added family selector (Auto/Weapon/Shield/Grenade/Class Mod/Artifact/Enhancement).
- Family selection is persisted locally and used to prevent cross-family mixing.
