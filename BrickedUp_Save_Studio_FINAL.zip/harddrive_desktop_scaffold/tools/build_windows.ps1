Param(
  [switch]$NoPause
)

Write-Host ""
Write-Host "=== BrickedUp Save Studio - Build (Windows) ===" -ForegroundColor Cyan
Write-Host ""

function Require-Cmd($name, $installHint) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] $name not found." -ForegroundColor Red
    Write-Host $installHint
    exit 1
  }
}

Require-Cmd node "Install Node.js LTS from https://nodejs.org/"
Require-Cmd npm  "Install Node.js LTS from https://nodejs.org/"
Require-Cmd cargo "Install Rust from https://www.rust-lang.org/tools/install"

if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
  Write-Host "[WARN] cl.exe not found. You likely need Visual Studio Build Tools (C++ workload + Windows SDK)." -ForegroundColor Yellow
}

Write-Host "[1/3] npm install" -ForegroundColor Gray
npm install
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[2/3] npm run tauri build" -ForegroundColor Gray
npm run tauri build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "[3/3] Done. Output: src-tauri\target\release\bundle\" -ForegroundColor Green
if (-not $NoPause) { Read-Host "Press Enter to close" | Out-Null }
